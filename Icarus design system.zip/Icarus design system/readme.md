# Icarus — Design System

**Operational memory for the physical world.** *"Version control for physical infrastructure."*

## What Icarus is

Icarus is event-sourced operational memory for physical assets and, closer to market, for compliance evidence. It doesn't just store current state — it preserves *how reality evolved*: every change, who made it, when, why, and the evidence behind each claim.

The go-to-market wedge is the **CMMC Readiness Scan**: a fixed-price (~$1,000), evidence-driven compliance assessment that reconstructs the proof behind an organization's CMMC controls by connecting read-only to systems like Microsoft 365, Entra ID, Intune, Defender, Active Directory, SharePoint, GitHub, Jira, and policy stores. To the customer it's a readiness report; underneath, every engagement builds a structured operational evidence graph that becomes the onboarding for the full Icarus platform — extensible to NIST 800-171, NIST CSF, CIS Controls, ISO 27001, SOC 2, HIPAA, and beyond compliance into general operational intelligence.

Sources: `uploads/Product Positioning- CMMC Readiness Scan.md`, `uploads/The Icarus Expansion Model.md`, `design.md` (original system notes), and the working pages listed under Index below.

## Principles

Every screen answers three questions:
1. **How do we know this?** — every fact traces to a source (a drawing, RFI, drone flight, email, voice note). Nothing is unattributed.
2. **How certain are we?** — confidence is shown explicitly, never hidden.
3. **What evidence supports it?** — the chain of custody from field to immutable ledger is one click away.

Operating rules that follow: **append-only, never edit** (a verified record is superseded, not overwritten); **candidate ≠ fact** (inferred relationships are marked and enter the ledger only after human review); **machine data wears mono** (IDs, coordinates, hashes, timestamps, confidence are always JetBrains Mono); **hairlines, not shadows** (1px rules and a strict grid — dossier/blueprint, not soft cards); **orange is attention, not brand** (signal orange marks what needs a human — never decoration).

## Content fundamentals

- **Voice:** plain, declarative, evidence-first. Short sentences. No hype adjectives ("revolutionary", "seamless"). States facts and lets the evidence chain be the proof.
- **Person:** product copy speaks about the system in third person ("the scan connects to…", "every engagement constructs…"); marketing CTAs speak to the reader directly ("Book a scan", "Find out exactly how ready you are").
- **Casing:** section labels and mono data are UPPERCASE with wide tracking (0.1–0.2em). Headlines and body copy are sentence case.
- **Signature lines:** the footer doctrine repeats across surfaces — *"How do we know this · How certain · What evidence"*, *"Candidate ≠ Fact · human-in-the-loop"*, *"Icarus remembers reality."* Positioning against peers is one line: *OpenSpace captures · Buildots measures · Digital Twins model · Icarus remembers.*
- **Numbers:** always specific and sourced (confidence scores, control counts, dollar prices) — never vague ("many", "significant").
- **Emoji:** never used, anywhere.

## Visual foundations

- **Color:** two surface modes share one ink-and-signal palette. Paper mode (default — dossier, marketing, registry) runs warm neutrals (`--canvas #D8CDB6` through `--surface-paper #F4EEE1`). Console mode (dark — review/triage/monitoring) runs `--console-bg #1B1710` through `--console-line #3A3124`. The public marketing site runs a lighter variant: pure white canvas with `#FBFAF7`/`#FCFBF8` banded sections and an inverted `#15110A` band. Signal orange (`#E5511C`) is attention/active/focal only; status green (`#1F8A4C`) means live/healthy/append-only-active. See tokens/colors.css.
- **Type:** Inter for product display & UI (weight 800, tight -0.025 to -0.028em tracking for headlines; 400–600 for body/labels). Geist 200–300 for the marketing site's airier editorial voice. JetBrains Mono for everything machine-generated or machine-verifiable — IDs, coordinates, hashes, timestamps, confidence values, and small uppercase section labels (0.1–0.16em tracking). See tokens/typography.css.
- **Spacing & shape:** radius is 0–1px on structural surfaces; component "cards" in the live component library use a soft 4px radius; nothing is pill-shaped except live-status dots. Borders are structural `1px solid` hairlines (ink on paper, `--console-line` on console) — never shadows. Panel padding 16–20px; section gutters 26–56px; page padding 32–56px. Layout favors three-column instrument grids (identity · timeline · evidence) with fixed side columns (~296–372px) and a fluid center.
- **Backgrounds:** flat color fields and hairline grids only — no gradients, no photography-heavy hero treatments. Faint dot-grids (radial-gradient dots) or blueprint cross-hatch stand in for imagery plates on model/hero areas.
- **Animation:** minimal — reveal-on-scroll fades/translate (opacity + translateY, ease `cubic-bezier(.22,1,.36,1)`, ~0.7s) on marketing pages; a slow pulse (2.4s ease-in-out) on live-status dots. No bounces, no spring overshoot.
- **Hover / press states:** buttons and links darken or underline; no scale/shrink press effects; live elements pulse opacity rather than color-shift.
- **Iconography:** no icon set. The system uses typographic glyphs (→, •, mono-set status dots) instead of icons — see ICONOGRAPHY below.
- **Imagery:** none in the working pages beyond generated diagrams (evidence graphs, timelines) built from CSS/DOM, not photography.

## Iconography

Icarus does not use an icon font, SVG icon set, or emoji. "Iconography" is typographic: a bordered square + orange dot as the wordmark mark, mono-set arrows (→) for relationships/CTAs, and small solid-color dots for live/status indicators. If a future surface needs true icons, match this restraint — thin, single-weight, monochrome — rather than introducing a filled icon-pack style.

## Index

- `styles.css` — root stylesheet entry point (imports only)
- `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css` — design tokens
- `components/core/` — Button
- `components/trust/` — TrustChip, ConfidenceBar (the Trust Spine primitives)
- `components/data/` — SpecRow, KpiCell, EventRow, EvidenceCard, RelationshipCard
- `guidelines/` — foundation specimen cards (colors, type, spacing, trust spine)
- `Icarus Design System.dc.html` — the original all-in-one live foundations + component reference
- `design.md` — original prose design system notes (superseded in structure by this readme + tokens, kept for history)

### Working product & marketing pages (existing UI kits)
- `Icarus Landing.dc.html` / `Icarus Landing copy.dc.html` — marketing site (Geist editorial expression)
- `Icarus Readiness Scan.dc.html` / `Icarus Readiness Scan Mobile.dc.html` — CMMC Readiness Scan product page, desktop + mobile
- `Icarus Workstation.dc.html` / `Icarus Workstation copy.dc.html` — three product directions: Dossier · Console · Field
- `Icarus Dashboard.dc.html` — portfolio overview template
- `Icarus Market & Model.dc.html`, `Icarus Financial Model.dc.html`, `Icarus Investment Memo.dc.html` — investor-facing documents
- `Icarus Vision Deck.dc.html` — pitch deck

## Intentional additions

None — the component inventory (Button, TrustChip, ConfidenceBar, SpecRow, KpiCell, EventRow, EvidenceCard, RelationshipCard) is drawn directly from the "Component inventory" section of `design.md` and the live catalogue in `Icarus Design System.dc.html`.
