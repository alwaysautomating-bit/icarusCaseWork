# Vanta

## Canonical Position

- Market leader in compliance automation with 15,000+ customers mentioned in the source bundle, 400+ integrations, 1,400+ automated tests, hourly testing, auditor portal, and trust-center style workflows. Sources: [Vanta compare page](https://www.vanta.com/compare/secureframe), [Vanta enterprise page](https://www.vanta.com/resources/best-compliance-software-for-enterprise).
- Pricing in the source bundle ranges from about $10K-$12K for smaller deployments to $60K-$120K+ for enterprise. Recommended use: competitive pricing analysis, investor memo. Sources: [SOC 2 Auditors pricing comparison](https://soc2auditors.org/insights/soc-2-software-pricing-comparison/), [SmallBizHandbook comparison](https://smallbizhandbook.com/security-compliance/vanta-vs-drata), [AutomationLabz comparison](https://www.automationlabz.com/compare/vanta-vs-drata).
- Vanta is repeatedly framed as SOC 2 / ISO 27001 first, with limited CMMC depth in the bundle, even though later-stage expansion includes FedRAMP, CMMC, and NIST 800-53. Sources: [Sacra Vanta analysis](https://sacra.com/research/vanta-at-220m-year/), [Vanta resources](https://www.vanta.com/resources/best-compliance-software-for-enterprise).

## Wedge Lessons

- Vanta is the strongest precedent for `compliance as a wedge`: productized prerequisite, recurring spend, low churn, then expansion into adjacent trust and risk workflows. Sources: [Sacra wedge analysis](https://sacra.com/chat/h/aeda6694-5d7d-499f-9caf-54d63e91b7f7/), [Sacra Vanta analysis](https://sacra.com/research/vanta-at-220m-year/).
- The source bundle cites Vanta at $152M ARR in 2024 and $220M ARR in July 2025, with 12,000+ customers and $4.15B valuation. Use only in investor materials and always label as company-analysis figures, not audited financials. Sources: [Sacra Vanta analysis](https://sacra.com/research/vanta-at-220m-year/), [VentureBeat](https://venturebeat.com/security/compliance-automation-vanta/).

## Icarus-Relevant Gaps

- Template-heavy SSP and POA&M support.
- Broad but shallow CMMC specialization compared with an Icarus-style defense-first product.
- Generic evidence collection versus CUI-specific scoping, traceability, and assessment workflow.
