# Investor Objections

## Canonical Risk List

### Technology

- Unproven evidence-graph architecture for CUI-specific workflows
- Accuracy risk for CUI reasoning and NLP
- Real-time scale and integration complexity
- Security risk in a graph-centric architecture
- LLM hallucination risk without structured context

### Go-To-Market

- Market education burden
- Long defense sales cycles
- Need for C3PAO partnerships
- Price pressure from Vanta, Drata, and services
- Need to prove demand outside narrow defense niches

### Competition

- Vanta and Drata can expand downward into CMMC
- ServiceNow and GRC incumbents can expand sideways
- Palantir and defense-native players have credibility
- Consulting firms and C3PAOs may build their own workflow products

### Timing

- November 10, 2026 is both the wedge and the timing risk
- If rollout slips, urgency could soften
- If capacity remains constrained, customers may delay or exit instead of buying software

## Canonical Milestones From The Bundle

- 100+ customers
- $5M to $50M ARR ranges depending on objection class
- 10+ C3PAO partnerships
- 200+ integrations
- 95%+ readiness / accuracy proof points

Source bundle basis: the investor-objections report in the original inbox document, plus competition, market, and strategy reports that underpin the listed concerns.
