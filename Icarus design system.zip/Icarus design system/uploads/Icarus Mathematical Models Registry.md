# Icarus Mathematical Models Registry

**Purpose:** Central registry of mathematical, statistical, graph, and scoring models used or proposed within Icarus.

**Status Definitions**

| Status | Meaning |
|----------|----------|
| Production | Implemented and validated |
| Proven Elsewhere | Validated in BAE, Birdie, SAME, or another system |
| Experimental | Proposed, not validated in Icarus |
| Research | Future investigation only |

---

# Tier 0 — Proven Foundations

These models are simple, interpretable, auditable, and should be preferred before introducing more complex approaches.

---

## IM-001 Deterministic Weighted Scoring

**Status:** Proven Elsewhere

**Origin:** Birdie, SAME

### Formula

score = Σ(signal × weight)

### Purpose

Convert multiple weak signals into a single interpretable confidence score.

### Icarus Uses

- Candidate relationship scoring
- Asset matching
- Event similarity
- Review queue prioritization

### Example Signals

- same_asset
- same_location
- same_vendor
- same_document
- time_proximity
- tag_overlap

### Notes

Preferred starting point for all new inference systems.

---

## IM-002 Jaccard Similarity

**Status:** Proven Elsewhere

### Formula

J(A,B) = |A∩B| / |A∪B|

### Purpose

Measure overlap between sets.

### Icarus Uses

- Tag comparison
- Asset attribute overlap
- Event classification overlap
- Drawing revision comparison

---

## IM-003 Temporal Decay

**Status:** Proven Elsewhere

### Formula

proximity_score = exp(-Δt / τ)

### Purpose

Convert time distance into relevance.

### Icarus Uses

- Event correlation
- Candidate link scoring
- Pattern detection

### Notes

Preferred over binary "same week" logic.

---

# Tier 1 — Probabilistic Models

These models should only be introduced after sufficient training data exists.

---

## IM-101 Bayesian Hierarchical Logistic Regression

**Status:** Proven Elsewhere

**Origin:** InvoiceDelta (BAE)

### Formula

logit(P) = α + Σβᵢxᵢ

### Purpose

Estimate probability that a relationship is valid.

### Icarus Uses

- P(same event)
- P(relationship valid)
- P(entity match)

### Requirements

- TrainingSignals
- Human review outcomes
- Sufficient labeled examples

### Not For

Initial MVP

---

## IM-102 Posterior Predictive Checks

**Status:** Proven Elsewhere

### Purpose

Validate Bayesian models.

### Use

Required before promoting experimental probabilistic models to production.

---

## IM-103 Non-Centered Hierarchical Reparameterization

**Status:** Proven Elsewhere

### Purpose

Improve Bayesian model convergence.

### Use

Per-site effects

Per-asset effects

Per-project effects

---

# Tier 2 — Relationship Intelligence

---

## IM-201 String Similarity

**Status:** Experimental

### Candidate Algorithms

- Levenshtein
- Jaro-Winkler
- Token Similarity

### Use

SAME entity resolution.

### Example

Sterling Electric

vs

Sterling Electrical LLC

---

## IM-202 Graph Traversal

**Status:** Experimental

### Algorithms

- BFS
- DFS

### Purpose

Relationship discovery.

### Example Queries

What caused this event?

What is connected to this asset?

What evidence supports this change?

---

## IM-203 Relationship Confidence Aggregation

**Status:** Experimental

### Purpose

Combine evidence from multiple signals.

### Inputs

- Temporal decay
- Asset overlap
- Spatial overlap
- Approval chain overlap
- Document references

### Output

Candidate relationship confidence score.

---

# Tier 3 — Salience & Context

---

## IM-301 Salience Ranking

**Status:** Research

### Candidate Approaches

- Weighted centrality
- PageRank variants
- Recency weighting

### Purpose

Determine:

What matters right now?

### Example

Top 5 operational issues.

Most influential event this week.

Highest-risk unresolved item.

---

## IM-302 Context Accumulation Score

**Status:** Research

### Purpose

Measure confidence based on accumulated supporting evidence.

### Example

An event supported by:

- photo
- inspection
- approval
- maintenance record

should rank higher than an isolated observation.

---

# Tier 4 — Pattern Intelligence

---

## IM-401 Markov State Modeling

**Status:** Research

### Purpose

Model operational state transitions.

### Example

Planned

→ In Progress

→ Delayed

→ Approved

→ Completed

### Requirements

Large historical event volume.

---

## IM-402 Sequential Bayesian Updating

**Status:** Research

### Purpose

Update probabilities as new evidence arrives.

### Example

Failure likelihood increases as new observations accumulate.

---

## IM-403 Time Series Anomaly Detection

**Status:** Proven Elsewhere

**Origin:** BAE Spend Velocity

### Purpose

Detect abnormal behavior.

### Icarus Uses

Asset activity anomalies.

Maintenance anomalies.

Inspection anomalies.

Construction progress anomalies.

---

# Model Selection Doctrine

Use the simplest model capable of solving the problem.

Preferred progression:

1. Deterministic Scoring
2. Similarity Metrics
3. Graph Relationships
4. Bayesian Models
5. Pattern Intelligence
6. Predictive Systems

Do not introduce a higher-tier model unless the lower tier demonstrably fails to solve the problem.

---

# Current Recommended Build Order

Phase 1

- IM-001
- IM-002
- IM-003

Phase 2

- IM-201
- IM-202
- IM-203

Phase 3

- IM-101
- IM-102

Phase 4+

- IM-301+
- IM-401+

The goal is not mathematical sophistication.

The goal is trustworthy operational memory.