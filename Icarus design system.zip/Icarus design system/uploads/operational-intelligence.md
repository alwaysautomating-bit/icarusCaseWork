# Operational Intelligence

## Canonical Thesis

- `Operational Intelligence` is not presented as a stable official Gartner software category in the source bundle. Instead, adjacent official buckets include analytics and BI platforms, digital twins, event intelligence, and distributed transactional databases. Sources: [ThoughtSpot Gartner summary](https://www.thoughtspot.com/data-trends/business-intelligence/gartner-magic-quadrant-bi-analytics), [Querio summary](https://querio.ai/articles/gartner-magic-quadrant-analytics-business-intelligence-platforms-2024-2025), [Aerospike Gartner hype-cycle summary](https://aerospike.com/blog/gartner-2025-hype-cycle/), [Edge Total Intelligence press release](https://www.nasdaq.com/press-release/edge-total-intelligence-recognized-gartner-hype-cycle-future-enterprise-applications).
- In the source bundle, the useful distinction is:
  - BI = retrospective analysis
  - Operational intelligence = real-time awareness and action
  - Knowledge graph = semantic reasoning over entities and relationships
  - Event intelligence / AIOps = live-event correlation and outcomes

## Icarus Application

- Icarus is best framed as the intersection of operational intelligence, evidence graphs, and compliance automation.
- That means `category creation` is a plausible strategy, but it should be treated as positioning, not as an already validated market category.
