# CMMC Market Size

## Verified Facts

- About 80,000 contractors are expected to require Level 2 third-party assessment. This is the official DoD estimate cited through David McKeown in 2024. Recommended use: website, investor memo, pitch deck, product strategy. Sources: [MeriTalk](https://www.meritalk.com/articles/dod-expects-more-companies-to-need-cmmc-level-2-assessments/), [GovConWire](https://www.govconwire.com/2024/06/dod-cyber-leader-david-mckeown-previews-cmmc-2-0-applauds-tremendous-perseverance-of-its-architects/), [ExecutiveGov](https://www.executivegov.com/articles/david-mckeown-more-vendors-may-need-3rd-party-assessments-under-cmmc-2-0).
- The broader DIB is about 220,000 companies, with about 140,000 expected to stay in Level 1 self-assessment and about 600 in Level 3 DoD-led assessment. Recommended use: investor memo, product strategy, TAM slides. Sources: [Washington Technology](https://www.washingtontechnology.com/contracts/2024/10/cmmc-resources-companies-now-rule-here/400218/), [GovConWire](https://www.govconwire.com/2024/06/dod-cyber-leader-david-mckeown-previews-cmmc-2-0-applauds-tremendous-perseverance-of-its-architects/).
- The Level 2 estimate doubled from an earlier 40,000-company assumption to 80,000. Recommended use: pitch deck, investor memo, urgency framing. Sources: [MeriTalk](https://www.meritalk.com/articles/dod-expects-more-companies-to-need-cmmc-level-2-assessments/), [Neqter Labs](https://neqterlabs.com/cmmc-third-party-assessments/).

## Industry Estimates And Market Narratives

- The total CMMC compliance market is estimated at about $2.1B in 2024 and projected to reach about $6.7B by 2033 at 15.8% CAGR. Recommended use: investor memo, market analysis, fundraising deck. Source: [Micah Dickson market summary](https://www.linkedin.com/posts/micahdickson_govcon-cybersecurity-cmmc-activity-7400525790347640832-vhiu).
- Third-party services are estimated at about $800M in 2026 and $3.5B by 2031. Recommended use: pricing strategy, services adjacency analysis, investor memo. Source: [Micah Dickson market summary](https://www.linkedin.com/posts/micahdickson_govcon-cybersecurity-cmmc-activity-7400525790347640832-vhiu).
- Federal cyber services spending was described as $11.8B in FY2024, up 7.3% YoY, as a broader market driver. Recommended use: investor memo, category framing. Source: [Micah Dickson market summary](https://www.linkedin.com/posts/micahdickson_govcon-cybersecurity-cmmc-activity-7400525790347640832-vhiu).

## Canonical Takeaways

- The cleanest demand number is `80,000 Level 2 contractors`, because it ties directly to DoD leadership commentary.
- The cleanest market-shape framing is `220,000 total DIB -> 140,000 Level 1 -> 80,000 Level 2 -> 600 Level 3`.
- The cleanest projected TAM number is `"$6.7B by 2033"` but it should always be labeled as an industry projection, not a verified government fact.

## Contradictions To Watch

- Some sources refer to `76,000-77,000` Level 2 contractors, while the strongest official estimate is `80,000`. Use `80,000` as the canonical figure and note the lower numbers as rounding variation. See [facts/contradictions.md](/C:/Projects/icarus-research/02-canonical/facts/contradictions.md).
