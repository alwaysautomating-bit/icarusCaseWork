# AI Agents And Structured Context

## Canonical Thesis

- The source bundle repeatedly uses the claim that roughly 80% of enterprise RAG projects fail, or 72% fail or underperform, because of poor data quality, weak retrieval, and lack of evaluation. Recommended use: product strategy, not customer-facing marketing unless carefully labeled. Source: [Crewscale](https://www.crewscale.com/blog/rag-is-dead-long-live-context-engineering).
- The bundle frames `context engineering` as broader than RAG: retrieval, memory, tools, orchestration, and evaluation. Source: [Crewscale](https://www.crewscale.com/blog/rag-is-dead-long-live-context-engineering).
- The bundle also cites Gartner-style `year of context` language and a prediction that 40% of enterprise applications will feature task-specific AI agents by late 2026. Use only as analyst framing. Source: [Crewscale](https://www.crewscale.com/blog/rag-is-dead-long-live-context-engineering).

## Icarus Application

- The strongest internal product lesson is not `we need AI agents`.
- It is `we need clean, structured, evaluatable operational context before agent workflows become trustworthy`.
- Evidence graphs and operational context are treated in the bundle as the enabling substrate.
