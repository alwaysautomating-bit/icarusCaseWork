# Icarus v2 Completion Sprint — Relationship Graph, Context, and Asset Passport Expansion

You are working in the Icarus repo.

Current status:

Phase 1 (Trust Spine Foundation) is complete.

Phase 2 (Relationship Intelligence) is largely complete.

Implemented:

- capture ingestion
- extraction pipeline
- candidate link generation
- deterministic scoring
- Jaccard similarity
- temporal decay
- review workflow
- training signals
- audit events
- Supabase persistence
- relationship review UI

The system successfully supports:

```text
capture
→ extraction
→ candidate link
→ review
→ training signal
→ operational event
→ event evidence
→ asset passport
→ audit trail
```

---

# Objective

Complete Phase 2.

The goal is NOT additional AI.

The goal is making relationships, evidence, and context explorable.

Icarus should become an operational memory system capable of reconstructing reality from connected evidence.

---

# Do Not Build

Do not build:

- Bayesian models
- Pattern-of-Life
- Hawkes processes
- Forecasting
- Salience ranking
- LLM reasoning agents
- PostGIS
- Blockchain
- Predictive analytics
- Vector search systems

Those belong to future phases.

---

# Build Slice A — Relationship Graph Layer

Expand use of:

```text
event_relationships
candidate_links
event_evidence
```

Support relationship types:

```text
supports
references
caused_by
follow_up
same_asset
same_location
derived_from
supersedes
related
```

Create graph traversal services:

```text
server/lib/contextGraph.ts
```

Responsibilities:

- fetch related assets
- fetch related events
- fetch supporting captures
- fetch evidence
- fetch candidate links
- prevent infinite loops
- configurable traversal depth

Recommended:

```ts
getAssetContext(assetId, depth)
getEventContext(eventId, depth)
```

---

# Build Slice B — Asset Context API

Create:

```text
GET /api/assets/:id/context
```

Response:

```json
{
  "asset": {},
  "events": [],
  "evidence": [],
  "captures": [],
  "candidate_links": [],
  "related_assets": [],
  "audit_events": [],
  "relationship_summary": {
    "event_count": 0,
    "evidence_count": 0,
    "capture_count": 0,
    "candidate_count": 0
  }
}
```

Purpose:

Return everything known about an asset.

This becomes the foundation of the Asset Passport.

---

# Build Slice C — Event Context API

Create:

```text
GET /api/events/:id/context
```

Response:

```json
{
  "event": {},
  "assets": [],
  "captures": [],
  "evidence": [],
  "related_events": [],
  "candidate_links": [],
  "audit_events": []
}
```

Purpose:

Return everything known about a single operational event.

---

# Build Slice D — Asset Passport 2.0

Upgrade:

```text
src/components/AssetPassport.tsx
```

Current passport appears focused on metadata.

Expand to show:

## Identity

- asset name
- asset type
- status
- location

## Timeline

Chronological event history.

Example:

```text
2026-01-12 Installed
2026-01-15 Surveyed
2026-01-22 Utility conflict discovered
2026-01-29 Relocation approved
```

## Evidence

Show linked:

- captures
- files
- photos
- documents

## Relationships

Show:

- related assets
- related events
- candidate links

## Confidence

Display:

```text
Verified
High Confidence
Medium Confidence
Low Confidence
Rejected
```

Based on linked records.

## Audit

Display audit history.

---

# Build Slice E — Event Detail View

Create:

```text
src/components/EventContextPanel.tsx
```

Purpose:

Operational-event deep dive.

Display:

- event details
- linked assets
- supporting captures
- supporting evidence
- related events
- audit history

Think:

Wikipedia page for an operational event.

---

# Build Slice F — Timeline Reconstruction

Create:

```text
server/lib/timelineBuilder.ts
```

Generate chronological history from:

- operational_events
- event_relationships
- event_evidence

Expose:

```text
GET /api/assets/:id/timeline
```

Response:

```json
[
  {
    "date": "...",
    "event_type": "...",
    "event_id": "...",
    "confidence": 0.92
  }
]
```

Timeline should be generated.

Not manually maintained.

---

# Build Slice G — Trust Visualization

Create shared UI utilities:

```text
src/components/ConfidenceBadge.tsx
```

Display:

- verified
- high confidence
- medium confidence
- low confidence
- rejected

Use existing deterministic scores.

No new models.

Visualize trust level everywhere:

- candidate links
- events
- asset passport
- context views

---

# Build Slice H — Relationship Explorer

Create:

```text
src/components/RelationshipExplorer.tsx
```

Simple expandable tree.

Not a graph visualization library.

Example:

```text
Generator Pad B
 ├── Events
 │     ├── Relocation
 │     ├── Survey
 │
 ├── Evidence
 │     ├── Drone Photo
 │     ├── Field Note
 │
 └── Related Assets
       ├── Utility Line A
       └── Generator B
```

Goal:

Make relationship structure understandable.

Keep implementation lightweight.

---

# Build Slice I — Operational Search

Create:

```text
GET /api/search
```

Search across:

- assets
- operational_events
- captures
- evidence
- candidate_links

Input:

```text
?q=generator relocation
```

Response:

Grouped results.

Purpose:

Allow users to discover connected operational memory quickly.

No vector search.

Simple SQL search is sufficient.

---

# Testing

Add tests for:

- asset context retrieval
- event context retrieval
- graph traversal depth limits
- timeline reconstruction
- relationship explorer data shaping
- operational search
- confidence classification

Ensure:

```bash
npm run lint
npm run test
npm run build
```

all pass.

---

# Documentation

Update:

```text
knowledge/models/MODEL_DECISION_LOG.md
```

Add:

## Phase 2 Complete

Implemented:

- IM-001 Deterministic Weighted Scoring
- IM-002 Jaccard Similarity
- IM-003 Temporal Decay
- Relationship Graph
- Asset Context
- Event Context
- Timeline Reconstruction
- Trust Visualization

Deferred:

- IM-101 Bayesian Hierarchical Logistic Regression
- Pattern-of-Life
- Predictive Intelligence

Reason:

Insufficient training signal volume.

Human-reviewed relationship data must accumulate before probabilistic models are justified.

---

# Definition Of Done

Icarus should now support:

```text
Capture Reality
↓
Connect Reality
↓
Verify Reality
↓
Audit Reality
↓
Reconstruct Reality
```

A user should be able to click any asset and immediately understand:

- what happened
- when it happened
- why it happened
- what evidence supports it
- what events are related
- what assets are connected
- who reviewed it
- how confident the system is

without leaving the Asset Passport.