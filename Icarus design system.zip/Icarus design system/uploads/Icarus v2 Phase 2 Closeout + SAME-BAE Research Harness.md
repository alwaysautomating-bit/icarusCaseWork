# Icarus v2 Phase 2 Closeout + SAME/BAE Research Harness

You are working in the Icarus repo.

Phase 2 is now functionally complete.

Recently implemented:

- `server/lib/relationshipScoring.ts`
- `server/lib/candidateLinkService.ts`
- `server/lib/contextGraph.ts`
- `server/lib/timelineBuilder.ts`
- `server/lib/search.ts`
- `src/components/RelationshipReviewPanel.tsx`
- `src/components/AssetPassport.tsx`
- `src/components/EventContextPanel.tsx`
- `src/components/ConfidenceBadge.tsx`
- `src/components/RelationshipExplorer.tsx`
- `src/lib/confidence.ts`
- `src/lib/relationshipExplorer.ts`
- expanded `src/types.ts`
- updated `server/api.ts`
- updated Phase 2 Supabase migrations
- updated tests and model docs

Verified:

- `npm run lint`
- `npm run test`
- `npm run build`
- `npm run seed:trust-spine`

Runtime checked:

- `GET /api/assets/:id/context`
- `GET /api/events/:id/context`
- `GET /api/assets/:id/timeline`
- `GET /api/search`
- `POST /api/candidate-links/generate`
- `PATCH /api/candidate-links/:id/review`

---

# Objective

Close Phase 2 cleanly and prepare the repo for Phase 2.5 model research.

Do not replace the deterministic relationship scorer.

Do not introduce production Bayesian logic.

Do not add Pattern-of-Life, forecasting, vector search, PostGIS, blockchain, or LLM agents.

This slice is about:

1. release documentation
2. demo hardening
3. seed data quality
4. offline SAME/BAE research harness scaffolding

---

# Part 1 — Create Phase 2 Release Doc

Create:

```text
knowledge/releases/ICARUS_V2_PHASE2_COMPLETE.md
```

Include:

## Phase 2 Status

Icarus v2 Phase 2 is complete.

The system now supports:

```text
Capture Reality
↓
Connect Reality
↓
Verify Reality
↓
Audit Reality
↓
Reconstruct Reality
```

## Implemented

- deterministic relationship scoring
- Jaccard similarity
- temporal decay
- candidate link generation
- candidate link review
- training signals
- audit events
- context graph
- asset context API
- event context API
- generated timelines
- grouped operational search
- Asset Passport 2.0
- Event Context Panel
- ConfidenceBadge
- RelationshipExplorer

## Deferred

- SAME production model
- BAE production model
- Bayesian inference
- Pattern-of-Life
- prediction/forecasting
- salience ranking

## Reason For Deferral

The production system needs more human-reviewed `training_signals` before probabilistic intelligence can be justified.

Phase 2 intentionally keeps scoring deterministic, transparent, and auditable.

---

# Part 2 — Create Phase 2.5 Research Plan

Create:

```text
knowledge/models/ICARUS_PHASE2_5_MODEL_RESEARCH_PLAN.md
```

Define Phase 2.5 as offline model testing only.

## SAME

SAME means identity resolution.

It answers:

```text
Are these two records referring to the same real-world asset, event, location, or operational object?
```

Research inputs:

- `candidate_links`
- `training_signals`
- `captures`
- `assets`
- `operational_events`
- `event_relationships`

Initial output:

```json
{
  "pair_id": "...",
  "source_type": "...",
  "source_id": "...",
  "target_type": "...",
  "target_id": "...",
  "deterministic_score": 0.82,
  "human_label": "approved",
  "same_candidate_features": {},
  "p_same_experimental": null
}
```

Do not integrate SAME into production yet.

## BAE

BAE means behavioral / business / build-context shaping.

It answers:

```text
What kind of operational pattern is emerging from connected events?
```

Initial labels:

- delay cascade
- identity conflict
- evidence gap
- scope drift
- field condition change
- handoff risk
- unresolved review loop
- documentation gap

Do not build predictive BAE yet.

Start with labeled exports and comparison docs.

---

# Part 3 — Create Offline Experiment Folders

Create:

```text
experiments/same/
experiments/bae/
```

Add placeholder README files:

```text
experiments/same/README.md
experiments/bae/README.md
```

Each README should clearly say:

- this is offline research only
- production scoring remains deterministic
- experiments must not write to Supabase production tables
- outputs should be JSON/CSV artifacts only
- no model is promoted until enough reviewed `training_signals` exist

---

# Part 4 — Add Training Signal Export Script

Create:

```text
scripts/export-training-signals.ts
```

Behavior:

- reads reviewed `candidate_links`
- joins related `training_signals`
- includes source/target metadata where available
- includes deterministic score and signals fired
- writes JSON artifact to:

```text
experiments/same/data/training-signals-export.json
```

If no reviewed signals exist, write an empty array and a small metadata object.

Output shape:

```json
{
  "exported_at": "...",
  "row_count": 0,
  "source": "supabase",
  "rows": []
}
```

Add package script:

```json
"export:training-signals": "tsx scripts/export-training-signals.ts"
```

---

# Part 5 — Add SAME Baseline Evaluation Stub

Create:

```text
experiments/same/evaluate-baseline.ts
```

Behavior:

- reads `experiments/same/data/training-signals-export.json`
- compares deterministic score against human labels
- computes simple metrics if labels exist:
  - total rows
  - approved count
  - rejected count
  - average score for approved
  - average score for rejected
- writes:

```text
experiments/same/results/baseline-evaluation.json
```

Do not import ML libraries.

Do not add Bayesian logic.

This is a measurement harness only.

Add package script:

```json
"experiment:same:baseline": "tsx experiments/same/evaluate-baseline.ts"
```

---

# Part 6 — Add BAE Labeling Stub

Create:

```text
experiments/bae/label-patterns.ts
```

Behavior:

- reads exported relationship/training signal data if available
- creates a JSON file with empty/manual pattern label slots
- writes:

```text
experiments/bae/data/pattern-labels.json
```

Example shape:

```json
{
  "created_at": "...",
  "labels": [
    {
      "chain_id": "...",
      "events": [],
      "suggested_pattern_label": null,
      "human_pattern_label": null,
      "notes": ""
    }
  ]
}
```

Add package script:

```json
"experiment:bae:labels": "tsx experiments/bae/label-patterns.ts"
```

---

# Part 7 — Hardening Checks

Run:

```bash
npm run lint
npm run test
npm run build
npm run seed:trust-spine
npm run export:training-signals
npm run experiment:same:baseline
npm run experiment:bae:labels
```

Fix any failures.

---

# Definition Of Done

- Phase 2 release doc exists
- Phase 2.5 research plan exists
- SAME experiment folder exists
- BAE experiment folder exists
- training signal export script works
- SAME baseline evaluation script works
- BAE labeling stub works
- package scripts are added
- no production scoring behavior changes
- no Bayesian or predictive logic is introduced
- lint, test, build, seed, and experiment scripts pass