<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Icarus timeline

Direct answer: Here’s a concise, sourced timeline of the myth of Icarus (Daedalus and Icarus) showing the usual sequence of events and common variations across classical sources.[^1_1]

Timeline of events

- Daedalus’s background and crimes: Daedalus, famed Athenian craftsman, has a history of invention and violence (some accounts say he killed his nephew Talus) and later enters the service of King Minos of Crete.[^1_2][^1_3]
- Building the Labyrinth: Daedalus constructs the Labyrinth at Knossos to contain the Minotaur under Minos’s orders.[^1_3][^1_2]
- Imprisonment or confinement: After helping (or being blamed for helping) Theseus or for other offenses, Daedalus (and often his son Icarus) are kept at Minos’s court or effectively confined on Crete.[^1_2][^1_3]
- Plan to escape: Daedalus fashions wings from feathers and beeswax for himself and Icarus and instructs his son to follow a middle flight path — neither too high (sun) nor too low (sea).[^1_1][^1_2]
- The flight and fall: Icarus soars too high; the sun melts the wax, his wings disintegrate, and he falls into the sea and drowns (the sea is later called the Icarian Sea or the island Icaria named for him in many versions).[^1_1][^1_2]
- Daedalus’s afterwards: Daedalus continues to Sicily (often to King Cocalus’s court); Minos pursues him and in several accounts is killed there (various endings for Daedalus are reported).[^1_3][^1_2]

Notes on chronology and variations

- No fixed dates: Classical myths rarely give precise dates; the story’s placement relative to figures like Theseus, Heracles, or the Argonauts varies by source and tradition, so only relative ordering (Labyrinth → imprisonment → escape → Icarus’s fall → Daedalus in Sicily) is consistent.[^1_4][^1_1]
- Source differences: Ovid’s telling (Heroides / Metamorphoses referenced in modern summaries) popularized the moral “fly not too close to the sun,” but other Greek sources (Apoll
<span style="display:none">[^1_10][^1_11][^1_12][^1_13][^1_14][^1_15][^1_16][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://en.wikipedia.org/wiki/Icarus

[^1_2]: https://ancient-greece.org/mythology/daedalus-and-icarus/

[^1_3]: https://en.wikipedia.org/wiki/Daedalus

[^1_4]: https://www.reddit.com/r/Epicthemusical/comments/1fiipkz/could_odysseus_have_saved_him/

[^1_5]: ScreenRecording_06-25-2026-02-27-20_1.mov

[^1_6]: https://www.gauthmath.com/solution/1807173940331526/Create-a-timeline-of-what-happend-in-the-story-of-learus-and-daedalus-in-the-fol

[^1_7]: https://pota.goatley.com/icarus/timeline.html

[^1_8]: https://www.scribd.com/presentation/401255051/Daedalus-and-Icarus

[^1_9]: https://ask.metafilter.com/153291/How-old-was-Icarus

[^1_10]: https://historycooperative.org/the-myth-of-icarus/

[^1_11]: https://history18.com/icarus-and-daedalus/

[^1_12]: https://www.slideshare.net/slideshow/task-14-timeline/61857521

[^1_13]: https://icarus.fandom.com/wiki/Story

[^1_14]: https://brainly.ph/question/8552849

[^1_15]: https://www.scribd.com/presentation/636992277/DAEDALUS-AND-ICARUS-SIGNIFICANT-EVENTS

[^1_16]: https://satyori.com/mythology/daedalus-and-icarus/

