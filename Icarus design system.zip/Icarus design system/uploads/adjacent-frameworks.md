# Adjacent Frameworks

## Canonical Overlap Claims

| Framework | Canonical overlap view | Best use | Source |
| :-- | :-- | :-- | :-- |
| NIST SP 800-171 | Direct alignment with CMMC Level 2 | Product architecture, control library | [Axipro](https://axipro.co/cmmc-vs-nist-800-171/) |
| ISO 27001 | About 60-70% overlap / reuse potential | Product strategy, investor memo | [VSO reciprocity](https://vso-inc.com/cmmc-reciprocity-soc2-iso-27001-credit/) |
| SOC 2 | Partial overlap, especially around common security controls | Product expansion, sales deck | [Compyl comparison](https://compyl.com/blog/compliance-framework-comparison-soc2-iso27001-hipaa-pci-dss/), [VSO reciprocity](https://vso-inc.com/cmmc-reciprocity-soc2-iso-27001-credit/) |
| FedRAMP High | Strongest relevance at infrastructure layer | Product roadmap, cloud integrations | [VSO reciprocity](https://vso-inc.com/cmmc-reciprocity-soc2-iso-27001-credit/) |
| HIPAA | Security overlap via SOC 2 style controls | Long-range expansion | [Bright Defense](https://www.brightdefense.com/focus-frameworks/), [Compyl](https://compyl.com/blog/compliance-framework-comparison-soc2-iso27001-hipaa-pci-dss/) |

## Canonical Caveat

- The source bundle is consistent that there is `no formal reciprocity` in CMMC. Existing certifications help with evidence reuse, but they do not remove the need for CMMC-specific assessment. Source: [VSO reciprocity](https://vso-inc.com/cmmc-reciprocity-soc2-iso-27001-credit/).
