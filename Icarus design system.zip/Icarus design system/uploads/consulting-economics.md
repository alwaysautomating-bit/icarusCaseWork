# Consulting Economics

## What Buyers Pay For

| Service | Typical price | Deliverables | Source |
| :-- | :-- | :-- | :-- |
| Readiness review | $15,000-$19,000 | Documentation review, control validation, gap identification | [SysAudits](https://sysaudits.com/pricing/) |
| Readiness review 2 | $225/hour, 24-hour minimum | Walkthroughs, spot checks, documentation review | [SysAudits](https://sysaudits.com/pricing/) |
| Gap assessment | Starting around $3,500 | NIST 800-171 assessment, compliance matrix, SAR, POA&Ms, evidence traceability | [SSE Inc](https://www.sseinc.com/contact-us/gap-assessment/) |
| Pre-assessment | Around $2,500 | Final readiness check before scheduling | [Hire a Cyber Pro](https://www.hireacyberpro.com/cmmc) |
| Mock assessment | About $15,000-$25,000 | C3PAO-style evaluation and findings | [1st Defense CMMC](https://www.1stdefensecmmc.com/readiness-and-advisory), [Valiant-X](https://valiant-x.com/cmmc-capabilities/) |

## Typical Deliverables

- Gap analysis report, SAR, SSP, POA&M, compliance matrix, evidence traceability matrix, policy templates, network diagrams, mock assessment report, and C3PAO selection support recur across the source bundle. Sources: [SSE Inc](https://www.sseinc.com/contact-us/gap-assessment/), [1st Defense CMMC](https://www.1stdefensecmmc.com/readiness-and-advisory), [Blue Mantle](https://www.bluemantletech.com/cmmc/packages), [IGI Cybersecurity](https://igicybersecurity.com/cmmc-readiness).

## Model Comparison

| Model | Price pattern | Best fit | Limitation |
| :-- | :-- | :-- | :-- |
| Pure consulting | Roughly $15K-$60K+ per phase | Small businesses, one-time certification | Expensive and labor-heavy |
| Pure software | Roughly $7.5K-$50K per year | Tech-forward companies | Does not automate policy writing, auditor management, or risk decisions well |
| Hybrid | Roughly $15K-$30K per year | Buyers needing automation plus expert support | Still dependent on service capacity |
| Managed service | Roughly $25K-$50K per project | Turnkey buyers | Margin-heavy and harder to scale |

Sources: [CertifyOps comparison](https://www.certifyops.com/blog/vanta-vs-drata-vs-secureframe-comparison), [Petronella](https://petronellatech.com/compliance/cmmc-compliance-services/), [Newf Tech](https://www.newf.tech/solutions/advisory/services/cmmc-certification), [SysArc](https://www.sysarc.com/sysarc-cmmc-readiness-os/).

## Canonical Operating Insight

- The bundle repeatedly argues that GRC platforms cover only about 40-50% of total compliance work, while policy writing, SSP narrative creation, risk decisions, and auditor management remain manual. Recommended use: product strategy, pricing, pitch deck. Source: [CertifyOps](https://www.certifyops.com/blog/vanta-vs-drata-vs-secureframe-comparison).
- AI-augmented delivery is described as reducing the path to certification from 12-18 months to 6-9 months. Recommended use: website, sales deck, product strategy. Source: [Newf Tech](https://www.newf.tech/solutions/advisory/services/cmmc-certification).

## Product Implications

- Best wedge offer: automated or AI-assisted gap assessment.
- Best expansion offer: SSP and POA&M generation.
- Best defensible workflow: C3PAO selection, coordination, and evidence quality management.
