# Evidence Graphs

## Canonical Thesis

- The source bundle consistently argues that graph-based representations outperform document-only systems for relationship-heavy compliance and operational reasoning because they support explicit multi-hop traversal, inspectable query traces, and explainable reasoning. Sources: [Microsoft Fabric Graph](https://blog.fabric.microsoft.com/en-us/blog/graph-powered-ai-reasoning-preview?ft=07-2024%3Adate), [TechStrong](https://techstrong.ai/contributed-content/from-rag-to-reasoning-why-agentic-ai-needs-knowledge-graphs/), [EMISA journal](https://emisa-journal.org/emisa/article/view/311).
- The canonical compliance path in the bundle is `control -> policy -> evidence -> system -> CUI`, with cross-framework reuse layered on top. Sources: [Microsoft Fabric Graph](https://blog.fabric.microsoft.com/en-us/blog/graph-powered-ai-reasoning-preview?ft=07-2024%3Adate), [Borealis framework mapping](https://portal.borealissecurity.com/frameworks), [VSO reciprocity article](https://vso-inc.com/cmmc-reciprocity-soc2-iso-27001-credit/).
- Commercial analogs cited in the bundle include Microsoft Fabric Graph, Glean, DataWalk, Atlan, and Borealis Aurora. Sources: [Microsoft Fabric Graph](https://blog.fabric.microsoft.com/en-us/blog/graph-powered-ai-reasoning-preview?ft=07-2024%3Adate), [Gend/Glean](https://www.gend.co/en-ca/blog/knowledge-graphs-enterprise-ai), [DataWalk](https://datawalk.com/what-is-an-enterprise-knowledge-graph/), [Atlan](https://atlan.com/know/ai-agent/knowledge-graph-for-ai-agents/).

## Icarus Application

- Strongest technical moat in the bundle: evidence traceability plus explainability for C3PAO-facing workflows.
- Strongest product angle: unified evidence reuse across CMMC, ISO 27001, SOC 2, FedRAMP, and HIPAA.
