# Compliance As A Wedge

## Canonical Thesis

- Compliance works as a revenue-enablement wedge, not just a back-office workflow. Buyers increasingly require trust and compliance proof before meaningful vendor evaluation. Sources: [Sacra wedge analysis](https://sacra.com/chat/h/aeda6694-5d7d-499f-9caf-54d63e91b7f7/), [Sacra Vanta analysis](https://sacra.com/research/vanta-at-220m-year/).
- Vanta is the strongest precedent in the bundle: launched in 2018, expanded from SOC 2 automation into vendor risk, access reviews, pen testing, AI compliance, FedRAMP, and CMMC, while scaling revenue and ARPC. Sources: [Sacra Vanta analysis](https://sacra.com/research/vanta-at-220m-year/), [VentureBeat](https://venturebeat.com/security/compliance-automation-vanta/).
- Historical analogs include Auth0/Okta and CrowdStrike: win an urgent enterprise requirement first, then widen into a platform. Sources: [Sacra wedge analysis](https://sacra.com/chat/h/aeda6694-5d7d-499f-9caf-54d63e91b7f7/), [Businesses at Work references in the source bundle](https://www.okta.com/sites/default/files/2024-02/Okta-Businesses-at-Work-2024.pdf).

## Icarus Application

- The defense equivalent of SOC 2 gatekeeping is CMMC readiness before contract award.
- The strongest recurring monetization path is software priced against consulting replacement, not against audit fees alone.
- Expansion paths already present in the source bundle: C3PAO marketplace, multi-framework evidence reuse, multi-environment automation, operational intelligence, adjacent federal frameworks.
