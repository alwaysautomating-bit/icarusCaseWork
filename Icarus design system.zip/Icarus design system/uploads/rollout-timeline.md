# Rollout Timeline

## Canonical Timeline

| Phase | Date | Canonical interpretation | Best use |
| :-- | :-- | :-- | :-- |
| Phase 1 | November 10, 2025 | Level 1 and Level 2 self-assessments required; C3PAO assessments can be required at contracting officer discretion | Website timeline, sales materials |
| Phase 2 | November 10, 2026 | Level 2 third-party certification becomes mandatory at contract award | Pitch deck, investor memo, urgency copy |
| Phase 3 | November 10, 2027 | Certification required at option exercise; Level 3 DoD-led work begins | Product strategy, roadmap |
| Phase 4 | November 10, 2028 | Full CMMC across all DoD contracts; annual affirmations continue | Long-range planning, investor memo |

Sources: [Mainstream FAQ](https://www.mainstream-tech.com/cmmc-2-0-faqs/), [Quzara timeline](https://quzara.com/cmmc/timeline), [32 CFR Part 170 references in the source bundle](https://quzara.com/cmmc/timeline), [USACE notice](https://www.nau.usace.army.mil/Portals/71/docs/).

## Supporting Verified Facts

- As of April 2025, 85 organizations had achieved full Level 2 certification, 4 had conditional certification via POA&M, and 100+ assessments were in progress. Recommended use: progress tracking, ecosystem maturity discussion. Source: [Cyber AB town hall April 2025](https://www.cmmc.com/newsroom/cyber-ab-town-hall-04-2025).

## Implications

- The cleanest urgency date is `November 10, 2026` because that is when Level 2 third-party certification becomes mandatory at contract award.
- Any timeline copy should include exact dates, not just `next year` or `soon`.
- Product strategy should anchor around `readiness before Phase 2` and `reassessment avoidance after Phase 2`.
