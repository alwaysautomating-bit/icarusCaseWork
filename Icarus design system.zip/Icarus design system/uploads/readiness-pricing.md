# Readiness Pricing

## Canonical Pricing Bands

### Gap Assessment

| Company size | Price range | Status | Best use | Source |
| :-- | :-- | :-- | :-- | :-- |
| <50 employees | $3,500-$10,000 | Industry estimate | Pricing page anchor, SMB segmentation | [CMMCCost](https://cmmccost.com/gap-assessment-cost) |
| 50-200 employees | $10,000-$25,000 | Industry estimate | Mid-market pricing, services comparison | [CMMCCost](https://cmmccost.com/gap-assessment-cost) |
| 200-500 employees | $25,000-$45,000 | Industry estimate | Enterprise discovery, scope sizing | [CMMCCost](https://cmmccost.com/gap-assessment-cost) |
| 500+ employees | $35,000-$60,000+ | Industry estimate | Enterprise discovery, value narrative | [CMMCCost](https://cmmccost.com/gap-assessment-cost) |

### Total Readiness

| Company size | Price range | Status | Best use | Source |
| :-- | :-- | :-- | :-- | :-- |
| 1-25 employees | $20,000-$80,000 | Industry estimate | SMB cost anchor | [Forem article](https://open.forem.com/cyber_comply_3fd55a5f72a4/cmmc-readiness-cost-what-defense-contractors-should-expect-in-2025-5fmg) |
| 25-200 employees | $75,000-$200,000 | Industry estimate | Mid-market value narrative | [Forem article](https://open.forem.com/cyber_comply_3fd55a5f72a4/cmmc-readiness-cost-what-defense-contractors-should-expect-in-2025-5fmg) |
| 200+ employees | $200,000+ | Industry estimate | Enterprise value narrative | [Forem article](https://open.forem.com/cyber_comply_3fd55a5f72a4/cmmc-readiness-cost-what-defense-contractors-should-expect-in-2025-5fmg) |

### Assessment And Certification

| Item | Price range | Status | Best use | Source |
| :-- | :-- | :-- | :-- | :-- |
| C3PAO Level 2 assessment for small-medium orgs | $28,000-$35,000 | Firm pricing / high confidence | Pricing comparison, ROI messaging | [SysAudits](https://sysaudits.com/pricing/) |
| Official certification range | $15,000-$60,000 | Industry estimate | General market education | [Kiteworks](https://www.kiteworks.com/cmmc-compliance/compliance-costs/) |
| Five-environment assessment quote | $381,000 total, about $76,200 per environment | Industry estimate | Enterprise ROI story, scope-reduction messaging | [CMMC First](https://cmmcfirst.com/c3pao-assessment-bottleneck/) |
| Three-year small-business total | $487,970-$591,770 | Industry estimate citing official modeling | Investor memo, pricing shock story | [Powered by 1ten](https://poweredby1ten.com/intelligence/cmmc-compliance-cost), [Armando Seay summary](https://www.linkedin.com/posts/armandoseay_cmmc-cui-activity-7463581955188506625-BoMT) |

## Canonical Takeaways

- Use `gap assessment`, `total readiness`, and `third-party assessment` as separate buckets. The source bundle repeatedly mixed them.
- The best clean SMB anchor is `gap assessment starts around $3,500-$10,000`.
- The best clean mid-market anchor is `total readiness often lands around $75,000-$200,000`.
- The best clean enterprise shock stat is `$381,000 for five environments`.
