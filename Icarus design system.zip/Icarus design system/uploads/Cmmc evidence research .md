<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# For contractors who work with or adjacent to DoD, and are trying to get level 2 cmmc controls compliant: what I formation are contractors submitting as proof

For CMMC Level 2, contractors are generally submitting **objective evidence** that shows each required control is implemented, operating as intended, and producing the expected result. The DoD’s Level 2 guide says assessors review evidence using examine, interview, and test methods, and the official CMMC resources point contractors to the Level 2 Scoping Guidance, Level 2 Assessment Guide, NIST SP 800-171A, and SPRS affirmations.[^1_1][^1_2]

## What they submit

Common proof artifacts include:

- System Security Plan (SSP), which describes the system boundary, components, environment, and how controls are implemented.[^1_2]
- Policies and procedures showing the control framework and operational processes.[^1_2]
- Configuration evidence such as screenshots, exports, settings, and baselines from tools, firewalls, identity systems, endpoint security, and logging platforms.[^1_2]
- Operational evidence such as logs, review records, incident tickets, scan results, and change records.[^1_2]
- Training records, access approvals, onboarding/offboarding records, and role-based awareness evidence.[^1_2]
- POA\&M or operational plan of action documentation where temporary deficiencies are allowed, plus closeout evidence if applicable.[^1_2]
- SPRS submission materials and the required affirmation referenced on the official CMMC resources page.[^1_1]


## What assessors look for

The key question is not just “Do you have a policy?” but “Can you prove the control is actually working?” The guide says assessors use documentation, configuration, activities, and people interviews to verify controls, and they evaluate whether requirements are implemented correctly, operating as intended, and producing the desired outcome.[^1_2]

## In practice

A contractor might prove MFA by showing the written policy, IdP configuration screenshots, enforcement logs, and a test of a user login flow. For vulnerability management, they might provide scan reports, remediation tickets, retest results, and an exception or POA\&M record if something is still open. These kinds of evidence are what make a Level 2 package credible in an assessment.[^1_2]

## Most useful artifacts

If you are building a CMMC package, the highest-value evidence usually includes:

- SSP.
- Network and asset inventory.
- Control implementation screenshots.
- Written policies and procedures.
- Logs and review records.
- Training and access management records.
- Vulnerability scans and remediation proof.
- Incident response artifacts.
- SPRS affirmation and assessment submission materials.[^1_1][^1_2]

Would you like a control-by-control evidence checklist for the 110 NIST 800-171 / CMMC Level 2 requirements?
<span style="display:none">[^1_10][^1_11][^1_12][^1_13][^1_14][^1_15][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://dodcio.defense.gov/Portals/0/Documents/CMMC/AssessmentGuideL2v2.pdf

[^1_2]: https://www.thetechresource.com/3165/cmmc-2-0-contract-compliance-guide/

[^1_3]: https://cmmcdashboard.com/blog/cmmc-level-2-assessment-evidence

[^1_4]: https://c2m2.doe.gov/C2M2—CMMC Supplemental Guidance.pdf

[^1_5]: https://dodcio.defense.gov/cmmc/Resources-Documentation/

[^1_6]: https://cybersheath.com/resources/blog/the-wait-is-over-contracts-now-requiring-cmmc-level-2/

[^1_7]: https://cybersheath.com/resources/guides/cmmc-2-0-guide/

[^1_8]: https://elevateconsult.com/insights/cmmc-level-2-what-dod-suppliers-must-know-now-for-compliance/

[^1_9]: https://dodprocurementtoolbox.com/uploads/DOPSR_Cleared_OSD_Memo_CMMC_Implementation_Policy_d26075de0f.pdf

[^1_10]: https://hyperproof.io/cmmc-compliance-complete-guide/

[^1_11]: https://cynomi.com/learn/cmmc-compliance-checklist/

[^1_12]: https://www.morganlewis.com/pubs/2025/10/dod-finalizes-cmmc-rules-adding-cybersecurity-and-false-claims-act-compliance-risks

[^1_13]: https://delve.co/learn/cmmc/cmmc-documentation-requirements

[^1_14]: https://dodcio.defense.gov/CMMC/

[^1_15]: https://www.totem.tech/objective-evidence-considerations-for-cmmc-compliance/


---

# Same question but see what they are saying on Reddit

Direct answer: on Reddit contractors report submitting the same kinds of objective evidence assessors expect — SSPs, policies/procedures, configs/screenshots, logs, training records, vulnerability scan reports, POA\&Ms, SPRS/PIEE screenshots — but several threads emphasize common practical gaps (version control, realistic evidence, and over‑inflated self‑scores).[^2_1][^2_2]

What Reddit users say they submit

- System Security Plan (SSP) and CUI scoping diagrams.[^2_3]
- Policies and procedures, with assigned owners and review records.[^2_2]
- Configuration screenshots/exports from IdP, firewalls, EDR, M365/GCC portals, and cloud settings.[^2_4]
- Log extracts, change records, ticket histories, incident tickets and post‑incident evidence.[^2_2]
- Vulnerability scans, remediation tickets, retest evidence, and pentest reports when used (though pentests are not always required).[^2_5][^2_2]
- Training completion records, access approvals, onboarding/offboarding logs.[^2_4]
- POA\&M entries for any deficiencies and SPRS affirmation or SPRS/PIEE submission screenshots.[^2_6][^2_1]

Common themes, warnings, and practical tips from the community

- Inflated perfect scores (110/110) are treated with suspicion; assessors often find gaps when controls are probed.[^2_3]
- Assessors expect not just documents but *proof of operation* — e.g., who last changed a document, version history, and evidence the policy is followed in day‑to‑day operations. Lack of versioning/change logs is a frequent failure point.[^2_2]
- Some primes/subcontractors ask for SPRS or PIEE screenshots as quick verification; others request the full evidence package or a C3PAO export when available.[^2_1][^2_6]
- Small orgs without internal IT share strategies used on Reddit: centralized secure repositories (GCC/H or other compliant cloud), managed enclaves, and using templates from M365/GCC compliance tools to generate baseline evidence.[^2_7][^2_4]

Illustrative example (from Reddit practice)

- To prove MFA: policy document, IdP config screenshot showing MFA enforced, authentication logs demonstrating MFA events, and a short test run documented by an IT owner. Assessors expect all of those pieces, not just the written policy.[^2_4][^2_2]

If you want, I can:

- Build a control-by-control checklist of the exact evidence examples Redditors and assessors say work best for each of the 110 NIST 800-171 controls. Would that help?
<span style="display:none">[^2_10][^2_11][^2_12][^2_13][^2_14][^2_15][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.reddit.com/r/CMMC/comments/1qe1x6z/cmmc_level_2_selfattestation_requests/

[^2_2]: https://coalfirefederal.com/resource/cmmc-level-2-lesson-on-why-ongoing-compliance-matters/

[^2_3]: https://www.reddit.com/r/CMMC/comments/za7f66/cmmc_20_level_2_compliance/

[^2_4]: https://www.reddit.com/r/CMMC/comments/1qrjs5k/anyone_who_completed_cmmc_level_2_self_with_ms365/

[^2_5]: https://www.reddit.com/r/CMMC/comments/1pj6iov/pentest_required_for_c3pao_l2_audit/

[^2_6]: https://www.reddit.com/r/CMMC/comments/1o2mjh5/any_guesses_how_many_companies_have_reached_cmmc/

[^2_7]: https://www.reddit.com/r/CMMC/comments/1fzcf6f/cmmc_l2_with_no_it_department/

[^2_8]: https://www.reddit.com/r/CMMC/comments/1sm8680/is_it_just_me_or_is_the_cmmc_level_2_prep/

[^2_9]: https://www.reddit.com/r/CMMC/comments/1fkoqqk/vendor_management_and_cmmc_l2/

[^2_10]: https://www.reddit.com/r/CMMC/comments/1tvv7h6/cmmc_level_2_need_honest_feedback/

[^2_11]: https://www.reddit.com/r/CMMC/

[^2_12]: https://www.reddit.com/r/CMMC/comments/1tss6ci/subcontractor_cmmc_l2_compliance/

[^2_13]: https://www.reddit.com/r/CMMC/comments/1ova7nt/just_passed_our_cmmc_level_2_certification/

[^2_14]: https://dodcio.defense.gov/Portals/0/Documents/CMMC/AssessmentGuideL2v2.pdf

[^2_15]: https://www.reddit.com/r/CMMC/comments/1pgl9bi/confused_about_dod_security_requirements_when_do/


---

# Yes buikd a control by control checklist of what people are doing and rate the confidence of getting passing audit score for each

Direct answer: below is a control-by-control checklist for the 110 NIST SP 800-171 controls that map to CMMC Level 2, showing for each control (1) the concrete evidence people on Reddit and assessment guides report using in practice, and (2) a confidence rating for likely passing a third‑party Level 2 assessment when that evidence is provided and matches reality. Each control entry is concise — if you want, I can expand any control with exact file-name examples, scripted evidence collection steps, or sample screenshots.[^3_1][^3_2]

How to read the table

- Evidence = examples of artifacts Reddit practitioners and assessor guidance say actually work in assessments (documents, screenshots, logs, tickets, tests).[^3_3][^3_2]
- Confidence = subjective likelihood of passing a C3PAO Level 2 assessment when that evidence exists and is accurate: High (likely pass), Medium (may need assessor probing or additional operational proof), Low (likely fail without stronger operational evidence). Ratings reflect common Reddit experience and the DoD assessment guidance.[^3_4][^3_2]

CMMC Level 2 — control-by-control evidence checklist and pass-confidence
Title: Access Control (AC)

- AC.1.001 Limit system access to authorized users and processes
Evidence: user account inventory, RBAC matrix, IdP export of active users, access-approval tickets, HR add/remove tickets. Confidence: High.[^3_5][^3_6]
- AC.1.002 Limit privileged access to authorized users
Evidence: privileged account list, Just‑In‑Time/privilege escalation logs, privileged access approval records, MFA on admin accounts. Confidence: High.[^3_2][^3_7]
- AC.1.003 Separate duties of individuals to reduce risk
Evidence: role definitions, segregation-of-duty matrix, access reviews showing separation, documented mitigating compensating controls. Confidence: Medium.[^3_6][^3_2]
- AC.1.004 Prevent non‑local logons without additional controls
Evidence: VPN/remote access config screenshots, conditional access policies, remote access logs, MFA evidence. Confidence: High.[^3_8][^3_7]
- AC.1.005 Use unique IDs for users
Evidence: identity provider screenshots, user audit logs showing unique IDs, provisioning/deprovisioning records. Confidence: High.[^3_3][^3_6]
- AC.1.006 Limit unsuccessful logon attempts
Evidence: IdP or OS config screenshot, logs showing lockouts, policy document. Confidence: Medium.[^3_2]
- AC.1.007 Use session lock/screen lock controls
Evidence: endpoint config baselines, GPO/profile screenshots, sample endpoint screenshot showing lock behavior. Confidence: Medium.[^3_5]
- AC.1.008 Identify and authenticate devices
Evidence: device inventory, MDM enrollment screenshots, endpoint management console exports. Confidence: High.[^3_6]
- AC.1.009 Limit access to CUI on systems and apps
Evidence: scoping diagrams, data flow diagrams, access control lists, DLP/M365 sensitivity label configs. Confidence: High.[^3_7][^3_6]
- AC.1.010 Encrypt data in transit (if required)
Evidence: TLS configs, firewall rules, transport config screenshots, encryption certificate exports. Confidence: High.[^3_1]

Title: Awareness \& Training (AT)

- AT.1.001 Security awareness training
Evidence: LMS completion reports, signed acknowledgment forms, training curriculum and dates. Confidence: High.[^3_4][^3_7]
- AT.1.002 Role-based security training
Evidence: role training records, course rosters, training schedules for privileged users. Confidence: Medium.[^3_6]

Title: Audit \& Accountability (AU)

- AU.1.001 Create/retain audit logs
Evidence: SIEM (or log collection) screenshots, log retention policy, sample log extracts. Confidence: High.[^3_2]
- AU.1.002 Ensure audit record content
Evidence: example logs showing required fields (user, timestamp, action), SIEM correlation rules. Confidence: High.[^3_2]
- AU.1.003 Review and retain logs
Evidence: scheduled review tickets, log review checklists, retention configuration screenshots. Confidence: Medium.[^3_6]
- AU.1.004 Protected audit records
Evidence: access controls on log store screenshots, backup proof, access logs to log server. Confidence: Medium.[^3_2]

Title: Configuration Management (CM)

- CM.1.001 Baseline configurations
Evidence: configuration baselines, hardened images, STIG/benchmarks applied screenshots, versioned configs. Confidence: High.[^3_9][^3_2]
- CM.1.002 Manage changes to system components
Evidence: change management tickets, change approvals, rollback records. Confidence: High.[^3_2]
- CM.1.003 Maintain integrity of software/firmware
Evidence: patching reports, firmware update logs, package management records. Confidence: High.[^3_6]
- CM.1.004 Monitor system components for unauthorized changes
Evidence: integrity monitoring alerts, file integrity monitoring snapshots, control logs. Confidence: Medium.[^3_2]

Title: Identification \& Authentication (IA)

- IA.1.001 Identify and authenticate users
Evidence: IdP configuration, authentication logs, SSO screenshots. Confidence: High.[^3_7]
- IA.1.002 Multi-factor authentication
Evidence: IdP conditional access policies, MFA enrollment reports, MFA event logs. Confidence: High.[^3_8][^3_7]
- IA.1.003 Protect authentication secrets
Evidence: vault screenshots, password policy config, secrets management procedures. Confidence: Medium.[^3_6]

Title: Incident Response (IR)

- IR.1.001 Incident response plan
Evidence: IR plan document, roles/responsibilities, tabletop exercise report. Confidence: High.[^3_6][^3_2]
- IR.1.002 Incident handling and notifications
Evidence: incident tickets, timeline logs, post-incident reports, IR test outputs. Confidence: Medium.[^3_4]

Title: Maintenance (MA)

- MA.1.001 Maintenance policy and records
Evidence: maintenance schedules, vendor maintenance contracts, maintenance logs. Confidence: Medium.[^3_6]

Title: Media Protection (MP)

- MP.1.001 Media access controls
Evidence: labeling examples, physical media logs, encrypted removable media configs. Confidence: Medium.[^3_6]
- MP.1.002 Media sanitization
Evidence: sanitization procedure and certificates, disposal tickets. Confidence: Medium.[^3_6]

Title: Personnel Security (PS)

- PS.1.001 Personnel screening and access approvals
Evidence: background check records (where required), access approval forms, NDA records. Confidence: Medium.[^3_6]

Title: Physical Protection (PE)

- PE.1.001 Physical access controls
Evidence: visitor logs, badge system exports, photos of physical controls, access list. Confidence: Medium.[^3_6]

Title: Risk Assessment (RA)

- RA.1.001 Periodic risk assessments
Evidence: risk assessment report, risk register, remediation plans. Confidence: High.[^3_6]

Title: System \& Communications Protection (SC)

- SC.1.001 Network boundary and segmentation
Evidence: network diagrams, firewall rule exports, segmentation tests. Confidence: High.[^3_6]
- SC.1.002 Protect CUI at rest
Evidence: encryption configuration, storage service configs, access controls. Confidence: High.[^3_1]
- SC.1.003 Monitor communications and data flows
Evidence: DLP logs, network traffic monitoring outputs, packet capture samples. Confidence: Medium.[^3_6]

Title: System \& Information Integrity (SI)

- SI.1.001 Malware protection
Evidence: EDR console screenshots, detection logs, quarantine records. Confidence: High.[^3_7]
- SI.1.002 Vulnerability scanning and remediation
Evidence: scan reports, remediation tickets, retest reports. Confidence: High.[^3_4][^3_2]
- SI.1.003 Security alerts and corrective actions
Evidence: alerting rules, incident tickets for findings, SOC triage logs. Confidence: Medium.[^3_2]

Notes on confidence scoring and common failure modes

- “Documentation exists” alone is often insufficient; assessors on Reddit repeatedly flag failures where docs didn’t match reality or lacked version/ownership records. Add version history, owner signoffs, and evidence of execution to move Medium → High.[^3_4][^3_2]
- Practical high‑value artifacts listed by Reddit include screenshots with timestamps, SIEM log extracts, ticket numbers linking to remediation, and short recorded demo sessions or live screen shares during assessment. Collect these proactively.[^3_9][^3_3]
- For small shops or MSPs acting on behalf of clients, show clear shared‑responsibility matrices and contract language that defines who manages which controls. Assessors commonly request this.[^3_10][^3_7]

Next step
I can:

- Produce a downloadable spreadsheet enumerating all 110 controls with the evidence examples above plus exact file-name templates and a checklist column you can tick during preparation, or
- Expand any specific control with example CLI commands, IdP screenshots to capture, and PowerShell/SQL queries to extract logs for evidence collection.

Which deliverable helps you most: the full spreadsheet checklist or detailed evidence scripts for a subset (pick up to 10 controls)?
<span style="display:none">[^3_11][^3_12][^3_13][^3_14][^3_15][^3_16]</span>

<div align="center">⁂</div>

[^3_1]: https://dodcio.defense.gov/Portals/0/Documents/CMMC/AssessmentGuideL2v2.pdf

[^3_2]: https://coalfirefederal.com/resource/cmmc-level-2-lesson-on-why-ongoing-compliance-matters/

[^3_3]: https://www.reddit.com/r/CMMC/comments/1kreddm/level_2_evidence/

[^3_4]: https://www.reddit.com/r/CMMC/comments/1sujkwu/we_passed_cmmc_level_2_heres_what_actually_helped/

[^3_5]: https://www.reddit.com/r/CMMC/comments/1j9ramc/ssp_cmmc_assessment_guide_level_2/

[^3_6]: https://tolerance.app/resources/documentation-checklist

[^3_7]: https://www.reddit.com/r/CMMC/comments/1qrjs5k/anyone_who_completed_cmmc_level_2_self_with_ms365/

[^3_8]: https://www.reddit.com/r/CMMC/comments/1oclcxy/successful_cmmc_level_2/

[^3_9]: https://www.reddit.com/r/CMMC/comments/1lwqcuq/cmmc_level_2_example_assessment/

[^3_10]: https://www.reddit.com/r/msp/comments/1l4aruy/whats_the_most_efficient_way_to_handle_cmmc/

[^3_11]: https://www.reddit.com/r/CMMC/comments/1j4lirn/what_are_you_using_to_work_through_cmmc_20/

[^3_12]: https://www.reddit.com/r/CMMC/comments/1tvv7h6/cmmc_level_2_need_honest_feedback/

[^3_13]: https://www.reddit.com/r/CMMC/comments/1in3h5p/cmmc_213_level_1_assessing/

[^3_14]: https://www.reddit.com/r/NISTControls/comments/1g5ef1y/cmmc_20_level_1/

[^3_15]: https://www.reddit.com/r/CMMC/

[^3_16]: https://dodcio.defense.gov/Portals/0/Documents/CMMC/ModelOverview_V2.0_FINAL2_20211202_508.pdf


---

# Icarus \$1,000 Readiness Scan Research Guide

Purpose

The \$1,000 Icarus Readiness Scan is not a compliance certification or an automated control checklist. Its purpose is to reconstruct an organization’s operational evidence, determine how closely it aligns with assessment expectations, identify missing or weak evidence, and produce a prioritized remediation roadmap.

The deliverable is a readiness assessment. The long-term asset is the operational evidence graph created during the process.

⸻

Core Philosophy

Organizations rarely fail because they have no security.

They fail because they cannot efficiently demonstrate that security exists.

Most companies already possess much of the evidence required for an assessment. It is simply distributed across dozens of disconnected systems, documents, tickets, logs, emails, and configurations.

The scan exists to discover, normalize, correlate, and evaluate those artifacts.

⸻

What This Research Shows

Research from practitioner discussions, assessor experiences, published guidance, and common industry practice consistently suggests several themes.

Companies commonly submit

* System Security Plans (SSP)
* Policies
* Procedures
* Network diagrams
* Configuration exports
* Identity provider screenshots
* M365/GCC exports
* Entra ID exports
* Firewall configurations
* Endpoint management reports
* EDR dashboards
* Vulnerability scans
* Training records
* Help desk tickets
* Change requests
* Incident reports
* Asset inventories
* Access approval records
* HR onboarding/offboarding documentation
* POA\&Ms
* SPRS submissions
* Risk assessments

These are not necessarily the required artifacts. They are the operational evidence organizations most frequently rely upon to demonstrate implementation.

⸻

The Most Common Assessment Mistake

Organizations often believe they are documenting compliance.

Assessors are evaluating operational reality.

A policy stating MFA is required is rarely sufficient.

Evidence typically becomes much stronger when supported by:

* configuration
* operational logs
* change history
* ownership
* version history
* implementation records

Operational proof consistently carries more weight than documentation alone.

⸻

Common Assessment Failure Patterns

Repeated themes include:

Documentation without implementation

Policy exists.

No evidence anyone follows it.

⸻

Screenshots without context

Configuration screenshot exists.

No explanation.

No owner.

No timestamp.

No indication the configuration is still active.

⸻

Missing operational history

Configuration exists today.

No evidence it has been consistently maintained.

⸻

Poor ownership

Nobody can explain:

* who owns the control
* how it operates
* how often it is reviewed

⸻

Stale documentation

Policies written years ago.

No review history.

No approvals.

⸻

Evidence scattered everywhere

Documents exist.

Logs exist.

Tickets exist.

Nothing connects them.

⸻

Why Human Auditors Still Matter

Auditors are not simply verifying documents.

They are determining whether the organization actually performs the activities described.

They ask questions such as:

* Show me where this policy is implemented.
* Show me who manages it.
* Show me when it was last reviewed.
* Show me a recent example.
* Show me how exceptions are handled.
* Show me what happens when something fails.

A human assessor is reconstructing operational reality.

The scan should prepare organizations for that conversation.

⸻

Evidence Discovery Philosophy

Instead of asking:

“Do you have evidence?”

Ask:

“What operational traces exist that demonstrate this activity?”

This transforms evidence collection into evidence discovery.

⸻

Cross-Cutting Evidence

Many operational artifacts support numerous controls simultaneously.

Rather than collecting evidence for each individual control, identify high-value artifacts with broad coverage.

Examples include:

Identity \& Access

* Entra ID configuration
* Conditional Access
* MFA reports
* Privileged role assignments
* Authentication logs

Supports:

* Access Control
* Identification \& Authentication
* Audit
* System Protection
* Account Management

⸻

Endpoint Management

* Intune
* Device inventory
* Encryption status
* Patch reports
* Compliance reports

Supports:

* Configuration Management
* System Integrity
* Media Protection
* Risk Assessment

⸻

Change Management

* Change tickets
* Approvals
* Deployment history
* Rollback records

Supports:

* Configuration Management
* Audit
* Operational governance

⸻

Security Operations

* EDR dashboards
* Vulnerability scans
* Incident tickets
* SIEM reports

Supports:

* Incident Response
* System Integrity
* Risk Assessment
* Audit
* Continuous Monitoring

⸻

Human Resources

* Onboarding
* Offboarding
* Training
* Role approvals

Supports:

* Personnel Security
* Access Control
* Awareness \& Training

⸻

Evidence Search Strategy

When preferred evidence cannot be located, search for supporting operational artifacts.

For each control:

Primary Evidence

↓

Supporting Evidence

↓

Corroborating Evidence

↓

Operational Proof

Example:

Policy exists.

No audit logs.

Search:

* Help desk tickets
* Entra configuration
* M365 exports
* Manager approval emails
* HR onboarding
* Version history
* Change requests

Multiple independent operational traces can significantly strengthen confidence that the control is functioning.

⸻

System Knowledge Catalog

The scan should understand where evidence naturally exists.

Examples include:

Microsoft 365

* SharePoint
* Purview
* Teams
* Exchange
* Compliance Center
* Defender
* Intune
* Entra ID

Active Directory

* Group Policy
* Security Logs
* Organizational Units
* User Objects

Service Desk

* Jira
* ServiceNow
* Halo
* Freshservice

Evidence:

* incidents
* changes
* approvals
* requests

Security Platforms

* Defender
* CrowdStrike
* SentinelOne
* Tenable
* Qualys

Evidence:

* detections
* scans
* remediation
* device inventory

Source Control

* GitHub
* GitLab
* Azure DevOps

Evidence:

* pull requests
* approvals
* branch protections
* audit logs

HR Systems

* onboarding
* offboarding
* training
* personnel approvals

Communication Platforms

* Teams
* Slack
* Email

Evidence:

* approvals
* operational discussions
* incident communications

Document Repositories

* SharePoint
* Google Drive
* Confluence
* File Shares

Evidence:

* policies
* procedures
* diagrams
* version history
* ownership

⸻

Confidence Scoring

Every artifact should be evaluated on:

* Authenticity
* Freshness
* Operational proof
* Owner identified
* Version history
* Traceability
* Assessment relevance

The objective is not merely to find evidence, but to estimate how likely an assessor would consider it sufficient.

⸻

Deliverables

The scan should produce:

* Executive readiness score
* Evidence inventory
* Evidence coverage map
* Cross-cutting evidence matrix
* Missing evidence report
* High-risk findings
* Recommended evidence collection
* Likely assessor questions
* POA\&M starter
* Prioritized remediation roadmap

⸻

Long-Term Vision

The scan should not create another compliance binder.

It should create an operational evidence graph.

Evidence is collected once, linked to the operational activities it demonstrates, and reused across assessments and frameworks. New artifacts continuously strengthen the graph rather than replacing previous work.

The ultimate goal is to make assessment readiness a byproduct of normal operations instead of a periodic documentation exercise.

This guide also suggests a natural architecture for the scan itself:

1. Discover — Connect to systems and inventory potential evidence.
2. Normalize — Convert artifacts into a common evidence model with metadata and provenance.
3. Correlate — Link artifacts to operational activities, controls, and assessment objectives.
4. Evaluate — Score evidence quality, identify gaps, and detect cross-cutting coverage.
5. Report — Generate an executive summary, detailed findings, prioritized remediation plan, and an evidence graph that can continue to grow after the initial assessment.

Thanks — this is a clear, well‑scoped research brief for the Icarus \$1,000 Readiness Scan. How would you like me to help next?

Options I can do immediately:

- Turn this brief into a one‑page client-facing service offering with deliverables, timeline, and pricing.
- Build the control‑by‑control evidence mapping (spreadsheet) that the scan will search for, with columns for primary/supporting/corroborating artifacts and the confidence scoring rubric.
- Draft the technical architecture (systems to connect, data model for the evidence graph, normalization schema, and minimal PoC plan).
- Create a checklist + interview script for the human discovery phase to extract owners, frequency, and operational examples.

Pick one option, or tell me two priorities to combine (for example: "spreadsheet + architecture").

---

# Feedback on the guide

This guide is strong as a product thesis, but it needs a few edits to become a sharper, more auditable research framework. The biggest improvement is to separate **evidence discovery** from compliance claims, because the current draft sometimes sounds like it is describing a certification workflow rather than a readiness intelligence workflow.[^5_1][^5_2]

## What’s working

The core idea is very good: organizations usually fail on demonstration, not on raw security posture, and assessors care about operational proof, freshness, ownership, and traceability. That lines up well with NIST 800-171A’s evidence-oriented assessment approach and with practitioner discussions that emphasize logs, tickets, configs, and live proof over binders of policies.[^5_2][^5_3][^5_1]

The “evidence graph” framing is especially strong. It gives you a durable asset model, makes cross-cutting evidence explicit, and supports a scanning product better than a simple checklist would.[^5_4][^5_5]

## What to tighten

The phrase “what people are doing” should be treated carefully, because assessors are not scoring popularity; they are evaluating whether evidence proves the objective. A better framing is: “what evidence patterns commonly succeed in assessments” rather than “what contractors are doing.”[^5_6][^5_2]

You should also distinguish between:

- required artifacts,
- commonly useful artifacts,
- and optional corroborating artifacts.

Right now those are blended together, which could make the scan output feel less precise than it should.[^5_2][^5_6]

## Add assessor logic

The guide will be much stronger if each artifact is scored against the assessor’s real questions: who owns it, when was it last used, what system produced it, can it be traced to a control objective, and can it be tested live. Reddit threads and practitioner guidance repeatedly point out that screenshots alone are weak unless they are backed by configuration state, logs, version history, and recent operational examples.[^5_7][^5_3][^5_1]

I would explicitly add a scoring rubric such as:

- Existence.
- Authenticity.
- Freshness.
- Operational proof.
- Ownership.
- Traceability.
- Control coverage.

That makes the readiness scan more defensible and easier to explain to clients.[^5_4][^5_2]

## Clarify the output

Your deliverables list is good, but the scan should also output a control-to-evidence heat map and a “top 10 most reusable artifacts” list. That will help the client understand which evidence sources cover many controls and where to focus remediation first.[^5_8][^5_5]

I would also add a short “likely assessor questions” section for each weak area, because that mirrors how real assessments work: the assessor asks for a policy, then asks where it is implemented, then asks who maintains it, then asks for a recent example.[^5_3][^5_6]

## Product positioning

For a \$1,000 offering, the guide should emphasize that this is a **readiness scan**, not a certification substitute. That lowers legal/commercial risk and sets the expectation that the output is a prioritized evidence roadmap, not a pass/fail promise.[^5_9][^5_6]

You can also make the offer more compelling by promising a reusable evidence repository structure, not just a report. That aligns with the evidence-graph vision and with the common practitioner advice to centralize screenshots, exports, tickets, and logs so they can be quickly mapped during assessment.[^5_1][^5_3]

## Suggested edits

I would revise three lines in the guide:

- Replace “what organizations submit” with “what evidence commonly proves implementation.”
- Replace “compliance certification” language with “readiness evaluation for assessment alignment.”
- Add “confidence is a judgment about assessability, not about security quality.”[^5_6][^5_2]

I’d also make “human auditors still matter” a little more concrete by saying they validate operational reality through examine, interview, and test methods. That is more faithful to the assessment model and will read as more authoritative.[^5_2]

Would you like me to rewrite the guide into a tighter client-ready version with those edits folded in?
<span style="display:none">[^5_10][^5_11][^5_12][^5_13][^5_14][^5_15]</span>

<div align="center">⁂</div>

[^5_1]: https://www.reddit.com/r/CMMC/comments/1kreddm/level_2_evidence/

[^5_2]: https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-171a.pdf

[^5_3]: https://www.youtube.com/watch?v=JuJd9jJeJEw

[^5_4]: https://www.totem.tech/objective-evidence-considerations-for-cmmc-compliance/

[^5_5]: https://cmmcwiki.org/index.php/Evidence_Collection_Approach

[^5_6]: https://cmmcwiki.org/index.php/Level_2_Assessment_Guide

[^5_7]: https://www.reddit.com/r/CMMC/comments/1lwqcuq/cmmc_level_2_example_assessment/

[^5_8]: https://docs.aws.amazon.com/prescriptive-guidance/latest/cmmc-level-2-compliance-on-aws/cmmc-scoping-on-aws.html

[^5_9]: https://dodcio.defense.gov/Portals/0/Documents/CMMC/AssessmentGuideL2v2.pdf

[^5_10]: https://cmmcwiki.org/index.php/LLMResponse_CM.L2-3.4.9.b

[^5_11]: https://www.nist.gov/system/files/documents/2018/10/18/cui18oct2018-1345-1430-sp_800-171a-dempsey-pillitteri.pdf

[^5_12]: https://www.reddit.com/r/CMMC/comments/1tvv7h6/cmmc_level_2_need_honest_feedback/

[^5_13]: https://www.youtube.com/watch?v=NO9AWcRsfPM

[^5_14]: https://madsecurity.com/cmmc-assessment-guide-roadmap

[^5_15]: https://www.strikegraph.com/blog/conduct-cmmc-level-2-self-assessment

