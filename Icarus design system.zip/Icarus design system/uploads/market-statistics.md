# Market Statistics

## High-Confidence Reusable Stats

| Fact | Status | Recommended use | Source |
| :-- | :-- | :-- | :-- |
| 80,000 contractors require Level 2 third-party assessment | Verified fact | Website, pitch deck, investor memo | [MeriTalk](https://www.meritalk.com/articles/dod-expects-more-companies-to-need-cmmc-level-2-assessments/) |
| 220,000 total DIB companies | Verified fact | TAM slides, investor memo | [Washington Technology](https://www.washingtontechnology.com/contracts/2024/10/cmmc-resources-companies-now-rule-here/400218/) |
| 140,000 companies likely stay in Level 1 | Verified fact | Product segmentation, TAM slides | [Washington Technology](https://www.washingtontechnology.com/contracts/2024/10/cmmc-resources-companies-now-rule-here/400218/) |
| 600 companies likely require Level 3 | Verified fact | Product roadmap, service edge cases | [GovConWire](https://www.govconwire.com/2024/06/dod-cyber-leader-david-mckeown-previews-cmmc-2-0-applauds-tremendous-perseverance-of-its-architects/) |
| 103 authorized C3PAOs by March 31, 2026 | Verified fact | Supply-side bottleneck slides | [Sunstone summary](https://www.linkedin.com/posts/sunstonesecure_cmmc-defensecontracting-cybersecurity-activity-7447744969664212994-UycM) |
| 345 certified assessors in April 2025 | Verified fact | Ecosystem maturity, bottleneck context | [Cyber AB April 2025](https://www.cmmc.com/newsroom/cyber-ab-town-hall-04-2025) |
| 700+ certified professionals in April 2025 | Verified fact | Ecosystem maturity, recruiting context | [Cyber AB April 2025](https://www.cmmc.com/newsroom/cyber-ab-town-hall-04-2025) |
| 1,074 final certificates issued by March 31, 2026 | Verified fact | Adoption tracking, investor memo | [Sunstone summary](https://www.linkedin.com/posts/sunstonesecure_cmmc-defensecontracting-cybersecurity-activity-7447744969664212994-UycM) |

## Medium-Confidence Reusable Stats

| Fact | Status | Recommended use | Source |
| :-- | :-- | :-- | :-- |
| 6-8 month average wait time for assessments | Industry estimate | Website urgency, pricing, sales | [CMMC First](https://cmmcfirst.com/c3pao-assessment-bottleneck/) |
| 40-50% fail initial assessment | Industry estimate | Sales deck, product strategy | [CMMC First](https://cmmcfirst.com/c3pao-assessment-bottleneck/) |
| 25% fail pre-assessments | Industry estimate | Product strategy, consulting economics | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_cmmc-phase-1-readiness-gaps-a-gao-analysis-activity-7446149971696865280-A_m8) |
| 1% fully prepared | Industry estimate | Sales deck, fundraising narrative | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_cmmc-phase-1-readiness-gaps-a-gao-analysis-activity-7446149971696865280-A_m8) |
| Median SPRS score is 60 vs 110 target | Industry estimate | Sales deck, readiness messaging | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_cmmc-phase-1-readiness-gaps-a-gao-analysis-activity-7446149971696865280-A_m8) |
| $6.7B market by 2033 | Industry estimate | Investor memo, TAM deck | [Micah Dickson summary](https://www.linkedin.com/posts/micahdickson_govcon-cybersecurity-cmmc-activity-7400525790347640832-vhiu) |
| $381,000 quote for five environments | Industry estimate | Enterprise pricing story, scope-reduction positioning | [CMMC First](https://cmmcfirst.com/c3pao-assessment-bottleneck/) |
