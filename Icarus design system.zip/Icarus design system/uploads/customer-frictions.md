# Customer Frictions

## Canonical Frictions

| Friction | Strength | Why it matters | Best use | Source |
| :-- | :-- | :-- | :-- | :-- |
| CMMC requirements confusion | Highest | Buyers misunderstand when certification is required and what counts as CUI | Website, sales deck | [Reddit thread](https://www.reddit.com/r/defensecontracting/comments/1ry58p5/challenges_in_defense_contracting/) |
| SPRS score problems | High | Median score cited as 60 versus a target of 110, creating disclosure anxiety | Sales deck, product strategy | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_i-was-wrong-about-the-cmmc-bottleneck-activity-7459560608603074562-BU_J) |
| Timeline misalignment | High | Buyers expect 3-4 months; source bundle claims 12-18 months is more realistic | Website, product strategy | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_i-was-wrong-about-the-cmmc-bottleneck-activity-7459560608603074562-BU_J) |
| Personnel turnover | Medium | Program champions change and momentum breaks | Product strategy, onboarding design | [Reddit thread](https://www.reddit.com/r/defensecontracting/comments/1ry58p5/challenges_in_defense_contracting/) |
| Government process bottlenecks | Medium | Contracting flow and agency understanding remain inconsistent | Investor memo, roadmap | [Reddit thread](https://www.reddit.com/r/defensecontracting/comments/1ry58p5/challenges_in_defense_contracting/) |
| IT-only ownership | High | Standard requires governance plus an affirming official, not just IT staff | Website education, product workflow | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_i-was-wrong-about-the-cmmc-bottleneck-activity-7459560608603074562-BU_J) |
| False Claims Act anxiety | Medium | Buyers worry about exposing weak SPRS scores and control gaps | Sales deck, risk messaging | [David Koran summary](https://www.linkedin.com/posts/david-w-koran_i-was-wrong-about-the-cmmc-bottleneck-activity-7459560608603074562-BU_J) |
| Over-scoping | Medium | Whole-company scope drives unnecessary cost and complexity | Pricing, product strategy | [CMMC First](https://cmmcfirst.com/c3pao-assessment-bottleneck/) |
| CAGE code transfer issues | Medium | Record transfer failures create operational friction | Product strategy, workflow design | [Cyber AB April 2025](https://www.cmmc.com/newsroom/cyber-ab-town-hall-04-2025) |

## Product Implications

- Education and scoping are not just content problems; they are product workflow opportunities.
- The strongest pain themes are confusion, score anxiety, and schedule risk.
- Any GTM copy should speak to first-pass readiness, cleaner scoping, and less assessor waiting.
