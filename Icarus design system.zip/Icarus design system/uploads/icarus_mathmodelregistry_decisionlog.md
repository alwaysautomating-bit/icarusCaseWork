# MODEL_DECISION_LOG.md

**Purpose:** Record why a model was introduced, what alternatives were considered, what evidence justified adoption, and how success will be measured.

This file exists to prevent "model drift" where increasingly complex techniques are added without a clear operational need.

Every model added to Icarus should have an entry.

---

# Decision Record Template

## Model ID

IM-XXX

## Decision Date

YYYY-MM-DD

## Status

Proposed | Accepted | Deprecated | Replaced

## Problem Statement

What operational problem are we trying to solve?

## Candidate Approaches Considered

### Option A

Description

Pros

Cons

### Option B

Description

Pros

Cons

### Option C

Description

Pros

Cons

## Selected Approach

Chosen model.

## Why This Model Was Selected

What evidence supported the decision?

Examples:

- Simpler models failed.
- Accuracy improvement exceeded threshold.
- Human review burden was too high.
- Deterministic rules could not capture uncertainty.

## Supporting Evidence

Links to:

- Experiments
- Validation reports
- Synthetic datasets
- PPC results
- User testing

## Expected Inputs

Signals and data required.

## Expected Outputs

What the model produces.

## Human Review Requirement

Can humans override?

Required review threshold?

## Success Metrics

Examples:

- Precision
- Recall
- False Positive Rate
- Review Queue Reduction
- Time Saved

## Failure Conditions

Conditions that would justify removal or replacement.

## Notes

Additional observations.

---

# MODEL DECISION RECORDS

---

## MDR-001

### Model

IM-001 Deterministic Weighted Scoring

### Date

2026-06-20

### Status

Accepted

### Problem

Need a transparent way to rank candidate relationships before any training data exists.

### Alternatives Considered

#### Bayesian Logistic Regression

Pros:
- Handles uncertainty
- Learns weights automatically

Cons:
- Requires labeled training data
- Difficult to explain early results

#### Embedding Similarity

Pros:
- Handles semantic relationships

Cons:
- Less transparent
- Harder to audit

### Selected

Deterministic Weighted Scoring

### Reason

Icarus currently has no labeled relationship dataset.

A transparent baseline is required before introducing learned models.

### Evidence

Birdie trust scoring successfully uses deterministic weighted signals.

SAME architecture assumes deterministic scoring before Bayesian refinement.

### Inputs

- same_asset
- same_location
- temporal_decay
- tag_overlap
- document_reference_match

### Outputs

relationship_confidence_score

### Human Review

Required for all scores below auto-approval threshold.

### Success Metrics

- Human acceptance rate
- False relationship rate
- Review queue volume

### Failure Conditions

If deterministic scoring cannot separate accepted and rejected relationships with acceptable precision.

---

## MDR-002

### Model

IM-003 Temporal Decay

### Date

2026-06-20

### Status

Accepted

### Problem

Binary time windows create unrealistic relationship scoring.

### Alternatives

#### Same-Day Boolean

Pros:
- Simple

Cons:
- Loses nuance

#### Same-Week Boolean

Pros:
- Easy to implement

Cons:
- Arbitrary boundaries

### Selected

Exponential Temporal Decay

### Reason

Produces smooth relevance changes instead of hard cutoffs.

### Evidence

Previously used successfully in BAE proximity calculations.

### Formula

proximity_score = exp(-Δt / τ)

### Human Review

Not applicable.

### Success Metrics

Improved relationship ranking quality.

### Failure Conditions

Temporal proximity contributes little explanatory power.

---

## MDR-003

### Model

IM-101 Bayesian Hierarchical Logistic Regression

### Date

TBD

### Status

Proposed

### Problem

Deterministic scoring may eventually fail to capture relationship uncertainty accurately.

### Selected

Not yet approved.

### Prerequisites

Must have:

- candidate_links
- training_signals
- meaningful human review history
- validation dataset

### Evidence Required Before Adoption

- Deterministic baseline performance report
- Synthetic data evaluation
- Posterior predictive checks
- R-hat convergence validation

### Adoption Gate

This model may not be implemented solely because it is more sophisticated.

It must demonstrate measurable improvement over deterministic scoring.

---

# Model Adoption Doctrine

Before introducing any new model, answer:

1. What decision does this model improve?
2. What simpler model failed first?
3. What evidence supports adoption?
4. How will we know if it works?
5. Can a human understand the result?
6. Can a human override the result?

If these questions cannot be answered, the model is not ready for production.

---

# Principle

The objective of Icarus is not mathematical sophistication.

The objective is trustworthy operational memory.

Models are introduced only when they improve trust, explainability, or decision quality.