# Comparison Matrix

## Canonical Matrix

| Company | Category | Strengths in source bundle | Weaknesses in source bundle | Icarus angle |
| :-- | :-- | :-- | :-- | :-- |
| Vanta | Compliance automation | Scale, integrations, test coverage, trust workflows | Higher price, limited CMMC depth | CMMC-first, assessor workflow, SSP/POA&M |
| Drata | Compliance automation | Lower price, customization, framework add-ons | Still generic compliance-first | Defense specialization, CUI scoping |
| Secureframe | Compliance automation | Competitive pricing, daily testing | Less differentiated narrative | Better readiness workflow |
| AuditBoard | Enterprise GRC | Vendor risk, audit workflow | Less focused on SMB or defense specialization | Faster defense-specific motion |
| Hyperproof | GRC program management | Mapping and audit prep | Less distinct CMMC narrative | CMMC-first operating system |
| ServiceNow GRC | Enterprise workflow/GRC | Workflow gravity, enterprise breadth | Heavy, expensive, generic | Purpose-built for defense suppliers |
| Palantir | Security operations / defense | Defense credibility, operational analytics | Not primarily compliance automation | Compliance plus ops at lower complexity |
| Wiz | Cloud security | Cloud visibility, attack path analysis | Limited compliance depth | Evidence and readiness, not just cloud risk |
| Archer | Vendor risk | Third-party risk workflows | Narrower overlap | CMMC readiness and assessor coordination |

## Reusable Competitive Insight

- The source bundle repeatedly says the major compliance platforms automate evidence collection and control monitoring, but not the full manual stack of policy writing, SSP narrative, POA&M optimization, risk decisions, and auditor management. Source: [CertifyOps](https://www.certifyops.com/blog/vanta-vs-drata-vs-secureframe-comparison).
- The cleanest differentiation wedge is `CMMC / NIST 800-171 specialization + multi-environment automation + C3PAO workflow + evidence-graph explainability`.
