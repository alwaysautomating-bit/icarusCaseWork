# ICARUS ROADMAP & STRATEGIC COLLAPSE
## Version Control for Physical Infrastructure

### Core Thesis

Most systems capture information.

Very few systems preserve context.

OpenSpace captures reality.
Buildots measures progress.
Procore stores documents.
Digital Twins model current state.

Icarus preserves the history of how reality evolved.

The goal is not document management.

The goal is operational memory.

---

# The Problem

Today, answering a simple question often requires manual reconstruction:

> Why does this look different than spec?

A PM may need to review:

- Drone captures
- RFIs
- Inspection reports
- Approval emails
- BIM revisions
- Change orders

The cost is not missing data.

The cost is correlation labor.

---

# Product Definition

Icarus is an event-sourced operational memory platform for physical infrastructure.

Core Function:

Capture reality.
Structure evidence.
Preserve causality.
Reconstruct context.
Surface patterns.

---

# Architectural Stack

Reality
↓
Quick Capture
↓
Evidence Inbox
↓
Draft Events
↓
Verified Events
↓
Event Ledger
↓
Timeline Layer
↓
Relationship Layer
↓
Pattern Layer
↓
Operational Memory

---

# Foundational Concepts

## Event Sourcing

Current state is derived from historical events.

Not:

Current State → History

Instead:

Event History → Current State

---

## Five Vector Event Model

Every verified event should eventually contain:

### WHAT
What changed?

### WHO
Who performed or approved it?

### WHEN
When did it occur?

### WHERE
Where did it occur?

### WHY
Why did it happen?

---

## Evidence First

Evidence is never discarded.

Capture first.
Context later.

Examples:

- Photo
- Video
- Voice note
- Drone capture
- Inspection report
- Email
- RFI
- Drawing revision

---

# Product Roadmap

---

## PHASE 1
## Event Capture Foundation

Goal:

Create operational exhaust.

### Features

#### Quick Capture

Capture:

- Photos
- Videos
- Voice Notes
- Documents
- Drone Uploads
- Text Notes

Automatically attach:

- User
- Timestamp
- Project
- GPS

Output:

Inbox Item

---

#### Evidence Inbox

Status Types:

- Unprocessed
- Pending Context
- Pending Review
- Linked
- Archived

Purpose:

Prevent information loss.

---

#### Event Creation Workflow

Convert inbox items into events.

Support:

- Manual creation
- Agent-assisted creation

---

#### Event Ledger

Store:

- Event history
- Asset history
- Change history

Immutable.

Append-only.

---

#### Site Timeline

Display:

Discovery
↓
RFI
↓
Approval
↓
Change
↓
Inspection

---

#### Evidence Viewer

View:

- Photos
- PDFs
- Drone captures
- Approvals
- Comments

in one place.

---

# PHASE 2
## Relationship Engine

Goal:

Turn isolated records into stories.

### Relationship Types

- explains
- caused_by
- approved_by
- references
- supersedes
- verified_by
- related_to

---

### Relationship Sources

#### Explicit

Human-created.

Confidence = 1.0

---

#### Deterministic

Rule-based.

Examples:

- Same asset
- Same location
- Same time window
- Same milestone

---

#### Inferred

AI suggested.

Requires review.

Never becomes truth automatically.

---

### Relationship Suggestions

Example:

Photo likely belongs to:

Generator Pad Relocation Event

Confidence:
87%

Evidence:
- Same asset
- Same location
- Same week

---

# PHASE 3
## Reconciliation System

Goal:

Prevent information decay.

### Weekly Agent Workflows

#### Loose Item Review

Find:

- Orphaned captures
- Unlinked documents
- Unknown assets

---

#### Missing Why Analysis

Find:

Events missing rationale.

---

#### Missing Approval Analysis

Find:

Events missing approval chains.

---

#### Relationship Validation

Review AI-generated relationships.

---

#### Narrative Generation

Weekly Summary:

"What happened this week?"

---

#### Event Consolidation

Merge:

- Photos
- Emails
- RFIs
- Approvals

into coherent operational events.

---

# PHASE 4
## Version Control Layer

Goal:

Git for physical infrastructure.

### Site Timeline

Versions:

- Foundation Complete
- Steel Erected
- Rough-In Complete
- Commissioning

---

### Version Compare

Compare:

- Layout changes
- Asset movement
- Capacity changes
- Inspection outcomes

---

### Version Restore

Reconstruct previous site state.

---

### Version Tagging

Major milestone snapshots.

---

# PHASE 5
## Audit & Provenance Layer

Goal:

Trustworthy reconstruction.

### Audit Controls

Store:

- Event ID
- Actor
- Timestamp
- Evidence
- Version History

---

### Evidence Hashing

Detect tampering.

---

### Chain of Custody

Track:

- Creation
- Modification
- Approval
- Verification

---

### Audit Explorer

Questions:

- Who approved this?
- What changed?
- Why?
- What evidence exists?

---

# PHASE 6
## Pattern Intelligence

Goal:

Operational experience.

### Pattern Discovery

Example:

Utility Conflict
↓
RFI
↓
Relocation
↓
Delay

---

### Pattern Library

Store recurring operational sequences.

---

### Pattern Retrieval

Query:

Have we seen this before?

---

### Similar Event Search

Find:

Related historical events.

---

# PHASE 7
## Constellation & Salience Layer

Goal:

Understand context.

### Constellation Map

Visualize:

- Assets
- Events
- People
- RFIs
- Approvals
- Evidence

as connected systems.

---

### Salience Engine

Surface:

Top 5 Things That Matter

instead of 5,000 records.

Factors:

- Cost
- Schedule
- Safety
- Compliance
- Recurrence

---

# PHASE 8
## Operational Memory

Goal:

Institutional experience at scale.

Example Query:

Why does this generator pad differ from spec?

Icarus Returns:

- Original design
- Related RFIs
- Approval chain
- Inspection history
- Evidence
- Similar cases
- Downstream outcomes

---

# PHASE 9
## Knowledge Layer (OKF)

Goal:

Portable organizational memory.

Knowledge Objects:

- Assets
- Systems
- Standards
- Procedures
- Lessons Learned
- Failure Modes

Format:

Markdown + YAML

Open Knowledge Format (OKF)

---

# PHASE 10
## Pattern-of-Life & Predictive Intelligence

Goal:

Move from memory to foresight.

Questions:

- What normally happens here?
- What changed?
- Is this unusual?
- What usually happens next?

Models:

- Temporal Analysis
- Bayesian Updating
- Markov Chains
- Graph Analysis
- Pattern-of-Life Modeling

---

# Long-Term Positioning

OpenSpace captures reality.

Buildots measures reality.

Digital Twins model reality.

Icarus remembers reality.

And eventually:

Icarus helps explain why reality became what it is.