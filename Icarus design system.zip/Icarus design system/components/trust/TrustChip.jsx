import React from 'react';

const BASE = {
  display: 'inline-flex',
  alignItems: 'center',
  fontFamily: "'JetBrains Mono', ui-monospace, monospace",
  fontSize: 9,
  fontWeight: 600,
  letterSpacing: '0.1em',
  padding: '3px 6px',
  borderRadius: 3,
  lineHeight: 1,
  whiteSpace: 'nowrap',
  textTransform: 'uppercase',
};

const PAPER = {
  observed:  { color: '#8A7C63', border: '1px dashed #B0A084', background: 'transparent' },
  extracted: { color: '#7A6E54', border: '1px dotted #9A8C6E', background: 'transparent' },
  candidate: { color: '#C4430F', border: '1px solid #E5511C', background: 'rgba(229,81,28,0.07)' },
  reviewed:  { color: '#2A2418', border: '1px solid #2A2418', background: 'transparent' },
  verified:  { color: '#18130C', border: '1.5px solid #18130C', background: '#F3ECDD', fontWeight: 700 },
  ledgered:  { color: '#EDE3CE', border: '1.5px solid #18130C', background: '#18130C', fontWeight: 700 },
  rejected:  { color: '#8A7C63', border: '1px solid #B0A084', background: 'transparent', textDecoration: 'line-through' },
};

const CONSOLE = {
  observed:  { color: '#8A7C63', border: '1px dashed #4A4030', background: 'transparent' },
  extracted: { color: '#A8987A', border: '1px dotted #6B5E47', background: 'transparent' },
  candidate: { color: '#FF8A52', border: '1px solid #E5511C', background: 'rgba(229,81,28,0.14)' },
  reviewed:  { color: '#C9BCA0', border: '1px solid #6B5E47', background: 'transparent' },
  verified:  { color: '#1B1710', border: '1.5px solid #E8DFCB', background: '#E8DFCB', fontWeight: 700 },
  ledgered:  { color: '#1B1710', border: '1.5px solid #FF8A52', background: '#FF8A52', fontWeight: 700 },
};

// TrustChip — the six-step Trust Spine ramp (+ rejected). Information hardens into fact left to right.
export function TrustChip({ step = 'observed', mode = 'paper' }) {
  const table = mode === 'console' ? CONSOLE : PAPER;
  const v = table[step] || table.observed;
  return <span style={{ ...BASE, ...v }}>{step}</span>;
}
