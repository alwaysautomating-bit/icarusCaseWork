TrustChip marks any record with its place on the Trust Spine: observed (raw capture, dashed) → extracted (machine-parsed, dotted) → candidate (inferred, needs a human, orange) → reviewed (human-checked) → verified (confirmed, bold) → ledgered (sealed, filled). `rejected` is a strikethrough terminal state.

```jsx
<TrustChip step="candidate" />
<TrustChip step="ledgered" mode="console" />
```

Notes:
- Never invent a seventh step or reorder the ramp — authority always increases left to right.
- Orange (candidate) means "needs a human," not brand decoration — don't use it for anything else.
- Console mode re-tints the same steps for dark review/triage screens; don't change the step semantics.
