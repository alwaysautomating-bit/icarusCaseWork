ConfidenceBar renders one labeled row in a confidence decomposition — stack 2-3 to show how sub-scores (deterministic, model) combine into a final confidence.

```jsx
<ConfidenceBar label="DETERMINISTIC" value={76} />
<ConfidenceBar label="MODEL" value={83} />
<ConfidenceBar label="COMBINED" value={80} emphasis />
```

Notes: console-mode only (dark background); mark exactly one row `emphasis` — the combined/final score.
