/**
 * ConfidenceBar — one row of a confidence decomposition (e.g. DETERMINISTIC + MODEL -> COMBINED).
 * @startingPoint section="Trust" subtitle="Labeled confidence bar for console-mode decomposition panels" viewport="700x60"
 */
export interface ConfidenceBarProps {
  label: string;
  /** 0-100 */
  value: number;
  /** Highlights this row (e.g. the combined/final score) in signal orange. */
  emphasis?: boolean;
}
export function ConfidenceBar(props: ConfidenceBarProps): JSX.Element;
