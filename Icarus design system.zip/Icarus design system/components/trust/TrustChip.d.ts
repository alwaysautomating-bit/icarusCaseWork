/**
 * TrustChip — renders one step of the six-step Trust Spine (the system's signature component).
 * Authority increases observed → ledgered; chip treatment encodes the step so trust reads without reading.
 * @startingPoint section="Trust" subtitle="Six-step evidence-confidence ramp, paper & console" viewport="700x140"
 */
export interface TrustChipProps {
  /** Which step of the trust spine this evidence/record has reached. */
  step?: 'observed' | 'extracted' | 'candidate' | 'reviewed' | 'verified' | 'ledgered' | 'rejected';
  /** Surface mode — paper (light, default) or console (dark). */
  mode?: 'paper' | 'console';
}
export function TrustChip(props: TrustChipProps): JSX.Element;
