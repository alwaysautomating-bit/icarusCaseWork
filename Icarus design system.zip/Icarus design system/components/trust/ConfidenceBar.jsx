import React from 'react';

// ConfidenceBar — one row of the confidence decomposition: a labeled bar out of 100, console-mode only.
export function ConfidenceBar({ label, value = 0, emphasis = false }) {
  const labelColor = emphasis ? '#E8DFCB' : '#8A7C63';
  const valueColor = emphasis ? '#FF8A52' : '#C9BCA0';
  const barColor = emphasis ? '#E5511C' : '#8A7C63';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <span style={{ width: 130, fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 10, fontWeight: emphasis ? 600 : 400, color: labelColor, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</span>
      <div style={{ flex: 1, height: 8, background: '#2A2318', border: '1px solid #3A3124', overflow: 'hidden' }}>
        <div style={{ height: '100%', width: value + '%', background: barColor }} />
      </div>
      <span style={{ width: 42, textAlign: 'right', fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: emphasis ? 13 : 11, fontWeight: emphasis ? 700 : 400, color: valueColor }}>{value}</span>
    </div>
  );
}
