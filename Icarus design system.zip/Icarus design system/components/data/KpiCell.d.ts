/**
 * KpiCell — one large-numeral stat tile inside a hairline-divided KPI grid.
 * @startingPoint section="Data" subtitle="Stat numeral + mono caption grid tile" viewport="700x120"
 */
export interface KpiCellProps {
  value: string | number;
  label: string;
  /** Renders the numeral in signal-deep orange (e.g. a hash or attention metric). */
  accent?: boolean;
  borderRight?: boolean;
  borderBottom?: boolean;
}
export function KpiCell(props: KpiCellProps): JSX.Element;
