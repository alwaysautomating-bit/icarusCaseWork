import React from 'react';
import { TrustChip } from '../trust/TrustChip.jsx';

// EvidenceCard — source tag + trust chip, title, confidence bar, relationship line.
export function EvidenceCard({ tag, title, step = 'reviewed', confidence = 0, relation }) {
  const under = step === 'candidate' || step === 'extracted' || step === 'observed';
  const barColor = under ? 'var(--signal, #E5511C)' : 'var(--ink, #18130C)';
  return (
    <div style={{ border: '1px solid var(--hairline-soft-2, #CFC1A2)', background: 'var(--surface-paper, #F4EEE1)', padding: '11px 12px', borderRadius: 4 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
        <span style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9, fontWeight: 600, letterSpacing: '0.1em', color: 'var(--ink-faint, #87795F)', border: '1px solid var(--hairline-soft-2, #CFC1A2)', padding: '2px 5px' }}>{tag}</span>
        <TrustChip step={step} />
      </div>
      <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--ink, #18130C)', marginTop: 8, lineHeight: 1.3 }}>{title}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginTop: 9 }}>
        <div style={{ flex: 1, height: 4, background: 'var(--surface-alt, #E3D9C4)', border: '1px solid var(--hairline-soft-2, #CFC1A2)', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: confidence + '%', background: barColor }} />
        </div>
        <span style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 10, fontWeight: 600, color: 'var(--ink, #18130C)' }}>{confidence}</span>
      </div>
      <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9, letterSpacing: '0.06em', color: 'var(--ink-faint, #87795F)', marginTop: 8 }}>{relation}</div>
    </div>
  );
}
