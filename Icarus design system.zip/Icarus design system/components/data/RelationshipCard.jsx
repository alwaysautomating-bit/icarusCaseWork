import React from 'react';

// RelationshipCard — source -> REL -> target. Solid border when ledgered, dashed when still a candidate.
export function RelationshipCard({ source, target, relation, ledgered = true }) {
  return (
    <div style={{ display: 'flex', alignItems: 'stretch', border: ledgered ? '1.5px solid #E8DFCB' : '1.5px dashed #6B5E47', borderRadius: 4, overflow: 'hidden' }}>
      <div style={{ flex: 1, padding: 13, background: '#221C14' }}>
        <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9, letterSpacing: '0.12em', color: '#8A7C63', marginBottom: 7 }}>SOURCE</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#E8DFCB', lineHeight: 1.3 }}>{source}</div>
      </div>
      <div style={{ flex: 'none', width: 92, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#2A2318', borderLeft: '1px solid #3A3124', borderRight: '1px solid #3A3124' }}>
        <span style={{ fontSize: 20, color: '#E5511C', lineHeight: 1 }}>&rarr;</span>
        <span style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9, letterSpacing: '0.08em', color: '#FF8A52', marginTop: 5 }}>{relation}</span>
      </div>
      <div style={{ flex: 1, padding: 13, background: '#221C14' }}>
        <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9, letterSpacing: '0.12em', color: '#8A7C63', marginBottom: 7 }}>TARGET</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#E8DFCB', lineHeight: 1.3 }}>{target}</div>
      </div>
    </div>
  );
}
