import React from 'react';
import { TrustChip } from '../trust/TrustChip.jsx';

// EventRow — REF · DATE · EVENT · TRUST grid row in an asset history timeline. Selectable.
export function EventRow({ ref: reference, date, title, meta, step = 'ledgered', selected = false, last = false }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '64px 92px 1fr 130px', gap: 12, alignItems: 'center',
      padding: '13px 18px', borderBottom: last ? 'none' : '1px solid var(--hairline-soft, #D8CDB6)',
      borderLeft: selected ? '3px solid var(--signal, #E5511C)' : '3px solid transparent',
      background: selected ? 'rgba(229,81,28,0.06)' : 'transparent',
    }}>
      <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 11, fontWeight: 600, color: 'var(--ink, #18130C)' }}>{reference}</div>
      <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 11, color: 'var(--ink-muted, #4C4231)' }}>{date}</div>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '-0.01em', lineHeight: 1.25 }}>{title}</div>
        <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9.5, letterSpacing: '0.06em', color: 'var(--ink-faint, #87795F)', marginTop: 4 }}>{meta}</div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-start' }}><TrustChip step={step} /></div>
    </div>
  );
}
