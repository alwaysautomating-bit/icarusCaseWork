/**
 * RelationshipCard — console-mode source -> relation -> target link in the evidence graph.
 * @startingPoint section="Data" subtitle="Source -> relation -> target link, console mode" viewport="700x100"
 */
export interface RelationshipCardProps {
  source: string;
  target: string;
  /** Mono relation caption, e.g. "VERIFIES", "DOCUMENTS". */
  relation: string;
  /** Solid border when the relationship is ledgered/confirmed; dashed when still a candidate awaiting review. */
  ledgered?: boolean;
}
export function RelationshipCard(props: RelationshipCardProps): JSX.Element;
