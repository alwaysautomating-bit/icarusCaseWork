import React from 'react';

// KpiCell — a large Inter numeral over a mono caption; tile in a hairline-divided KPI grid.
export function KpiCell({ value, label, accent = false, borderRight = false, borderBottom = false }) {
  return (
    <div style={{ padding: '20px 18px', borderRight: borderRight ? '1px solid var(--hairline-strong, #18130C)' : 'none', borderBottom: borderBottom ? '1px solid var(--hairline-strong, #18130C)' : 'none' }}>
      <div style={{ fontFamily: "'Inter', system-ui, sans-serif", fontSize: 32, fontWeight: 800, letterSpacing: '-0.02em', color: accent ? 'var(--signal-deep, #C4430F)' : 'var(--ink, #18130C)' }}>{value}</div>
      <div style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 9.5, letterSpacing: '0.1em', color: 'var(--ink-faint, #87795F)', marginTop: 6, textTransform: 'uppercase' }}>{label}</div>
    </div>
  );
}
