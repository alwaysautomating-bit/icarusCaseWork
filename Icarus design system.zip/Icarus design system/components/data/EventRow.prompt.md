EventRow is one line of an asset's event history table — pair with a header row (REF / DATE / EVENT / TRUST mono labels) and stack rows with `last` on the final one.

```jsx
<EventRow ref="EVT-03" date="2026-06-03" title="Generator Pad Relocated 4ft East"
  meta="CHANGE ORDER · CARLOS REYES → JENNA PARK" step="verified" selected />
```
