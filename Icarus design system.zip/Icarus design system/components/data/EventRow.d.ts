/**
 * EventRow — one row of an asset-history timeline: REF · DATE · EVENT · TRUST.
 * @startingPoint section="Data" subtitle="Asset history row with trust chip, selectable" viewport="700x70"
 */
export interface EventRowProps {
  ref: string;
  date: string;
  title: string;
  /** Small mono caption, e.g. "CHANGE ORDER · CARLOS REYES -> JENNA PARK". */
  meta: string;
  step?: 'observed' | 'extracted' | 'candidate' | 'reviewed' | 'verified' | 'ledgered' | 'rejected';
  /** Adds the 3px orange left-marker + tinted background for the active row. */
  selected?: boolean;
  last?: boolean;
}
export function EventRow(props: EventRowProps): JSX.Element;
