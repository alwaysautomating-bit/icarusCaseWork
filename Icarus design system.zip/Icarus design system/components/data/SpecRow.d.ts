/**
 * SpecRow — one mono key/value line in an asset identity / spec table.
 * @startingPoint section="Data" subtitle="Mono key/value row for identity & spec tables" viewport="700x50"
 */
export interface SpecRowProps {
  label: string;
  value: string | number;
  /** Renders the value in signal-deep orange (e.g. a chain hash). */
  accent?: boolean;
  /** Omits the bottom hairline (last row in a group). */
  last?: boolean;
}
export function SpecRow(props: SpecRowProps): JSX.Element;
