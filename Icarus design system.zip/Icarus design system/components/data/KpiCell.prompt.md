KpiCell is one tile of a 2-col KPI grid — pair four in a 2x2 with borderRight/borderBottom toggled to draw the internal hairline cross.

```jsx
<KpiCell value="6" label="Evidence captures" borderRight borderBottom />
<KpiCell value="100%" label="Events verified" borderBottom />
<KpiCell value="4" label="Source actors" borderRight />
<KpiCell value="0x6f33" label="Ledger head hash" accent />
```
