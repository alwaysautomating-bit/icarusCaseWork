EvidenceCard is the atomic unit of the evidence graph — one sourced artifact with its trust step and confidence.

```jsx
<EvidenceCard tag="EMAIL" title="Owner Rep Approval — Pad Relocation 4ft East"
  step="verified" confidence={92} relation="VERIFIES · EVENT EVIDENCE" />
```

Notes: the confidence bar renders in orange when the step is below "reviewed" (still under-trust) and ink/dark once reviewed or better.
