import React from 'react';

// SpecRow — a mono key/value pair, hairline-separated. Used for asset identity tables.
export function SpecRow({ label, value, accent = false, last = false }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '9px 0', borderBottom: last ? 'none' : '1px solid var(--hairline-soft, #D8CDB6)' }}>
      <span style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 10, letterSpacing: '0.08em', color: 'var(--ink-faint, #87795F)' }}>{label}</span>
      <span style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 11, color: accent ? 'var(--signal-deep, #C4430F)' : 'var(--ink, #18130C)' }}>{value}</span>
    </div>
  );
}
