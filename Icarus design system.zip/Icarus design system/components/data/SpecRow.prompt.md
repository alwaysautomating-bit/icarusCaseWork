SpecRow is a single mono label/value row for identity tables (manufacturer, model, GPS, chain hash, etc).

```jsx
<SpecRow label="MANUFACTURER" value="Cummins" />
<SpecRow label="CHAIN HASH" value="0x6f33ab10" accent last />
```
