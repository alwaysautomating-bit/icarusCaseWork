/**
 * EvidenceCard — a single piece of evidence: source tag, trust chip, title, confidence bar, relationship line.
 * @startingPoint section="Data" subtitle="Evidence source card with confidence bar" viewport="700x160"
 */
export interface EvidenceCardProps {
  /** Source type, e.g. "EMAIL", "DRONE", "PHOTO". */
  tag: string;
  title: string;
  step?: 'observed' | 'extracted' | 'candidate' | 'reviewed' | 'verified' | 'ledgered' | 'rejected';
  /** 0-100 */
  confidence: number;
  /** Mono relationship caption, e.g. "VERIFIES · EVENT EVIDENCE". */
  relation: string;
}
export function EvidenceCard(props: EvidenceCardProps): JSX.Element;
