RelationshipCard shows one edge of the evidence graph: a source record pointing at a target via a named relation, dark console-mode only.

```jsx
<RelationshipCard source="INSPECTION · Report Jun 2" relation="VERIFIES" target="EVENT · Utility Conflict" ledgered />
<RelationshipCard source="PHOTO · CU-002 bracket wear" relation="DOCUMENTS" target="EVENT · CU-002 Vibration" ledgered={false} />
```

Notes: solid border = ledgered (confirmed), dashed = candidate awaiting human review — never mix the two meanings.
