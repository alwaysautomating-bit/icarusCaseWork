Button renders Icarus's five button treatments: primary (filled signal-orange), ghost (underlined text), outline (bordered), and two console-mode treatments for dark review/triage surfaces.

```jsx
<Button variant="primary" href="#" arrow>Launch Console</Button>
<Button variant="ghost" href="#">See how it works</Button>
<Button variant="consoleFilled">Approve → Ledger</Button>
```

Notes:
- Primary is the only filled color in the system outside of trust chips — reserve it for the one dominant action per screen.
- Console variants are always JetBrains Mono, uppercase, letter-spacing 0.1em — pair with a dark console-mode background.
- Never round corners beyond 4px; ghost/ underline variants have radius 0.
