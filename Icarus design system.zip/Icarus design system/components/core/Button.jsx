import React from 'react';

const BASE = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 9,
  fontFamily: "'Inter', system-ui, sans-serif",
  fontSize: 13,
  fontWeight: 600,
  letterSpacing: '0.02em',
  textDecoration: 'none',
  cursor: 'pointer',
  border: 'none',
  borderRadius: 4,
};

const VARIANTS = {
  primary: { background: 'var(--signal, #E5511C)', color: '#F4EEE1', padding: '11px 18px' },
  ghost: { background: 'transparent', color: 'var(--ink, #18130C)', padding: '11px 4px', borderBottom: '1px solid var(--ink, #18130C)', borderRadius: 0 },
  outline: { background: 'transparent', color: 'var(--ink, #18130C)', border: '1px solid var(--ink, #18130C)', padding: '9px 16px', fontSize: 12, fontWeight: 500 },
  consoleFilled: { background: 'var(--signal, #E5511C)', color: 'var(--console-bg, #1B1710)', padding: '12px', fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 11, letterSpacing: '0.1em', textAlign: 'center', justifyContent: 'center', textTransform: 'uppercase' },
  consoleOutline: { background: 'transparent', color: 'var(--console-text, #C9BCA0)', border: '1px solid var(--console-line, #4A4030)', padding: '12px', fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 11, letterSpacing: '0.1em', textAlign: 'center', justifyContent: 'center', textTransform: 'uppercase' },
};

// Button — the five button treatments used across Icarus surfaces.
// variant: 'primary' | 'ghost' | 'outline' | 'consoleFilled' | 'consoleOutline'
export function Button({ variant = 'primary', href, onClick, children, arrow = false, style }) {
  const v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} onClick={onClick} style={{ ...BASE, ...v, ...style }}>
      {children}
      {arrow ? <span>&rarr;</span> : null}
    </Tag>
  );
}
