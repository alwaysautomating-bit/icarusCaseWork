/**
 * Button — the five button treatments used across Icarus product and marketing surfaces.
 * @startingPoint section="Core" subtitle="Primary, ghost, outline & console button treatments" viewport="700x120"
 */
export interface ButtonProps {
  /** Visual treatment. Default 'primary'. */
  variant?: 'primary' | 'ghost' | 'outline' | 'consoleFilled' | 'consoleOutline';
  /** Renders as <a> when provided, else <button>. */
  href?: string;
  onClick?: () => void;
  /** Adds a trailing arrow glyph (→). */
  arrow?: boolean;
  children: React.ReactNode;
  style?: React.CSSProperties;
}
export function Button(props: ButtonProps): JSX.Element;
