# Icarus — Design System

**Operational memory for the physical world.**
Rev 01 · "Version control for physical infrastructure"

Icarus is event-sourced operational memory for physical assets. It doesn't just store the
current state of a site — it preserves *how reality evolved*: every change, who made it, when,
where, and why, with the evidence behind each claim. The design system exists to make that
provenance legible at a glance.

---

## 1. Principles

The interface answers three questions on **every** screen:

1. **How do we know this?** — every fact is traceable to a source (a drawing, RFI, drone flight, email, voice note).
2. **How certain are we?** — confidence is shown explicitly, never hidden.
3. **What evidence supports it?** — the chain of custody from field observation to immutable ledger is always one click away.

Operating rules that follow from this:

- **Append-only, never edit.** A verified record is superseded, not overwritten. The original stays in the ledger, intact.
- **Candidate ≠ Fact.** Inferred relationships are always marked. They enter the ledger only after human review; every decision is logged as a training signal.
- **Machine data wears mono.** IDs, coordinates, hashes, timestamps, and confidence values are set in JetBrains Mono so they read as *data*, not prose.
- **Hairlines, not shadows.** Structure comes from 1px rules and a strict grid — a dossier / blueprint feel, not soft cards.
- **Orange is attention, not brand.** The signal orange marks the thing that needs a human, the active state, the focal asset. It is never decoration.

---

## 2. Color

Two surface modes share one ink-and-signal palette.

### Paper mode (default — dossier, marketing, registry)
| Token | Hex | Use |
|---|---|---|
| `--canvas` | `#D8CDB6` | App background / workspace |
| `--surface-sand` | `#EAE0CC` | Primary panel surface |
| `--surface-paper` | `#F4EEE1` | Raised / header surface |
| `--surface-alt` | `#E3D9C4` | Secondary fill, ruler tracks, image plates |
| `--hairline-strong` | `#18130C` | Structural 1px borders |
| `--hairline-soft` | `#D8CDB6` / `#CFC1A2` | Internal dividers |

### Console mode (dark — review, triage, monitoring)
| Token | Hex | Use |
|---|---|---|
| `--console-bg` | `#1B1710` | Console background |
| `--console-panel` | `#221C14` | Panel / cell surface |
| `--console-deep` | `#2A2318` | Inset wells, bars |
| `--console-line` | `#3A3124` | Borders / dividers |
| `--console-text` | `#E8DFCB` | Primary text on dark |
| `--console-accent` | `#FF8A52` | Signal on dark (brighter orange) |

### Ink (shared)
| Token | Hex | Use |
|---|---|---|
| `--ink` | `#18130C` | Primary text |
| `--ink-graphite` | `#332A1C` | Secondary dark |
| `--ink-muted` | `#4C4231` | Body on sand |
| `--ink-faint` | `#87795F` | Mono labels, captions |

### Signal & status (shared)
| Token | Hex | Use |
|---|---|---|
| `--signal` | `#E5511C` | Attention, active, focal asset |
| `--signal-deep` | `#C4430F` / `#B8410E` | Hash text, pressed, emphasis |
| `--status-ok` | `#1F8A4C` | Live / healthy / append-only ledger active |

> Marketing surfaces (the public site) run a lighter variant: pure `#FFFFFF` canvas with the same
> ink and `#E5511C` signal, plus `#FBFAF7` / `#FCFBF8` for banded sections and `#15110A` for inverted bands.

---

## 3. Typography

Two families, sharply divided by role.

- **Inter** — display & UI. Headlines use weights **800** (product, tight `-0.025em`) on sand; the marketing site uses **Geist** weights **200–300** for an airier editorial voice. Body & labels: 400–600.
- **JetBrains Mono** — everything machine-generated or machine-verifiable: asset IDs, coordinates, hashes (`0x…`), timestamps, confidence values, and the small UPPERCASE `letter-spacing:0.1–0.16em` section labels.

### Scale (product / paper mode)
| Role | Size / weight | Notes |
|---|---|---|
| Display | 54–58px / 800 / `-0.025em` | Screen titles, line-height ~0.98 |
| Asset numeral | 40px / 800 | e.g. `GEN-014` |
| Stat numeral | 30–34px / 800 | KPI cells |
| Section head (Inter) | 14–15px / 600 | Panel titles |
| Mono section label | 9.5–11px / 600 / `0.12–0.16em` UPPERCASE | `ASSET HISTORY`, `PROVENANCE` |
| Body | 12.5–14px / 400–500 | |
| Mono data | 10–11px / 400–600 | IDs, coords, hashes |

---

## 4. Spacing, grid & shape

- **Radius: 0–1px.** Surfaces are rectangular. Chips may use 1px. Nothing is pill-shaped except live status dots.
- **Borders:** structural = `1px solid #18130C` (paper) / `#3A3124` (console). Internal dividers one step softer.
- **Panel padding:** 16–20px. Section gutters: 26–56px. Page padding: 32–56px.
- **Layout:** three-column instrument grids (identity · timeline · evidence). Fixed side columns (~296–372px), fluid center.
- **Texture:** dotted/cross-hatch fills (`repeating-linear-gradient` at 135°) stand in for imagery plates; faint dot or blueprint grids back model/hero areas.

---

## 5. The Trust Spine — the signature component

Information **hardens into fact** along a six-step ramp. Authority increases left → right; the
chip treatment encodes the step so trust is readable without reading.

| Step | Confidence | Chip treatment |
|---|---|---|
| **OBSERVED** | 0–30 | dashed border, faint ink — raw, unprocessed |
| **EXTRACTED** | 30–55 | dotted border, muted ink — machine-parsed |
| **CANDIDATE** | 55–75 | solid orange border, orange ink, faint orange fill — *needs a human* |
| **REVIEWED** | 75–90 | solid dark border, dark ink — human-checked |
| **VERIFIED** | 90–99 | heavy border, filled paper, bold — confirmed |
| **LEDGERED** | 100 · immutable | filled charcoal, light text, bold — append-only, sealed |

Every chip is JetBrains Mono, 9–9.5px, `0.1em`, UPPERCASE, `3px 6–7px` padding. Console mode
re-tints the same six steps onto the dark palette (faint→`#8A7C63`, candidate→`#FF8A52`,
ledgered→filled `#E8DFCB`).

---

## 6. Component inventory

All catalogued and rendered live in **`Icarus Design System.dc.html`**.

- **Trust chips** — the six-step ramp, paper + console variants, plus `REJECTED` (struck through).
- **Buttons** — primary (filled orange), ghost (underline), console (filled / outline) + decision pair `APPROVE → LEDGER` / `REJECT`.
- **Spec rows** — mono key / value pairs, hairline-separated; the asset identity table.
- **Event row** — `REF · DATE · EVENT · TRUST` grid; selectable, 3px orange left-marker on active.
- **Evidence card** — source tag + trust chip, title, confidence bar (orange under-trust / dark at-trust), relationship line.
- **Timeline ruler + markers** — mono date track with positioned event dots; active dot enlarges + turns orange.
- **Confidence decomposition** — `DETERMINISTIC` + `MODEL` → `COMBINED` bars.
- **KPI stat cell** — large Inter numeral + mono caption, hairline-divided row.
- **Relationship card** — source → `REL` → target, solid (ledgered) or dashed (candidate) border.
- **Token strip & masthead** — the system header: swatches + type + trust-spine scale under a 2px top rule.
- **Nav bar** — fixed, blurred, hairline-bottom; wordmark = bordered square + orange dot + `ICARUS`.

### Wordmark
A `26px` square with `1.5px` ink border enclosing a `7px` orange dot, followed by `ICARUS` in
Geist/Inter 500, `0.04–0.16em` tracking.

---

## 7. Voice

Plain, declarative, evidence-first. Footers carry the doctrine: *"How do we know this · How
certain · What evidence,"* *"Candidate ≠ Fact · human-in-the-loop,"* *"Icarus remembers
reality."* Positioning against peers is one line: *OpenSpace captures · Buildots measures ·
Digital Twins model · **Icarus remembers**.*

---

## 8. Files

| File | What it is |
|---|---|
| `Icarus Design System.dc.html` | Visual reference — foundations, trust spine, every component rendered |
| `Icarus Landing.dc.html` | Marketing site template (Geist editorial expression) |
| `Icarus Workstation.dc.html` | Three product directions: Dossier · Console · Field |
| `Icarus Dashboard.dc.html` | Portfolio overview template, built from the system |
| `design.md` | This document |
