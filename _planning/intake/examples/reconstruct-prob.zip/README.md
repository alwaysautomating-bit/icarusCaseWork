# reconstruct-prob

`reconstruct.prob` is a case-agnostic toolkit for converting fragmented, time-indexed records into explicit probabilistic model inputs and reproducible model runs.

It preserves five distinctions that matter in reconstruction work:

1. An observed event and a derived claim are different records.
2. Event time may be exact, approximate, ranged, or unknown.
3. Source confidence weights evidence; it does not silently become certainty.
4. Priors are versioned records with provenance.
5. Competing-model scores are relative explanatory weights, not declarations of truth.

## Install

```bash
pip install -e '.[dev]'
pip install -e '.[hmm,stats]'
pip install -e '.[bayes,survival,changepoint]'
```

## Package map

| Module | Responsibility | Optional engine |
| --- | --- | --- |
| `data.py` | Validated contracts and lifecycle states | Pydantic |
| `priors.py` | Prior creation, filtering, conjugate updates | PyMC |
| `hmm.py` | Latent state inference | hmmlearn |
| `hbm.py` | Partial pooling across subjects | PyMC + ArviZ |
| `survival.py` | Cox/Weibull time-to-event models | lifelines |
| `change_point.py` | Offline trajectory shifts | ruptures |
| `system.py` | Confidence-weighted handoff fragmentation | SciPy or NumPy |
| `narrative.py` | Competing-hypothesis normalization | NumPy |
| `utils.py` | UTC time bins and JSON-safe outputs | NumPy |

## Minimal example

```python
from datetime import datetime, timezone
from uuid import uuid4

from reconstruct.prob import Event, TimeWindow, create_beta_prior
from reconstruct.prob.data import TimePrecision
from reconstruct.prob.system import SystemFragmentationModel

owner_id = uuid4()
event = Event(
    owner_id=owner_id,
    case_id="case-123",
    subject_id="system-1",
    event_type="missed_follow_up",
    time=TimeWindow(
        start=datetime(2026, 1, 2, tzinfo=timezone.utc),
        end=datetime(2026, 1, 2, tzinfo=timezone.utc),
        precision=TimePrecision.EXACT,
    ),
    confidence=0.8,
)

prior = create_beta_prior(
    "handoff failure",
    "generic_operations",
    "p_fragmented_handoff",
    alpha=1,
    beta=9,
    source="internal baseline v1",
)

result = SystemFragmentationModel(prior).compute_fragmentation_score([event])
```

## Supabase

Run `supabase/migrations/0001_probabilistic_reconstruction.sql` through your normal migration workflow. The migration provides:

- four core tables for events, priors, model runs, and claims;
- three junction tables so evidence and prior references have real foreign keys;
- UTC timestamp ranges and explicit precision;
- `jsonb` only for genuinely extensible fields;
- owner-scoped RLS on every exposed table;
- shared priors that authenticated users may read but cannot create or alter;
- indexes for the main timeline, type, tag, prior, and subject queries.

The migration intentionally does not create source-document or case tables. `source_ids` and `case_id` are adapter boundaries so Icarus can connect its existing Evidence and Project/Case identities without duplicating them here.

## Boundaries

- A model output should support reconstruction, prioritization, and hypothesis testing. It should not be presented as a clinical diagnosis, legal conclusion, fraud determination, or safety certification.
- HMM state labels are assigned after fitting; numerical state `2` is not inherently “crisis.”
- The HMM transition arrays are initialization values in this adapter. A fully Bayesian transition prior belongs in a PyMC state-space implementation.
- The change-point interval reports sampling resolution. It is deliberately labeled so it cannot be mistaken for a Bayesian credible interval.
- A Cox model requires proportional-hazards checks. Use a time-varying or parametric alternative when that assumption fails.

## Test

```bash
pytest
```

