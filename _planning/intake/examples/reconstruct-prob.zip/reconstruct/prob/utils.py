"""Deterministic time binning, feature extraction, and JSON serialization."""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Iterable

import numpy as np

from .data import Event


FeatureFn = Callable[[Event], dict[str, float | int | None]]


def _floor_time(value: datetime, time_bin: str) -> datetime:
    value = value.astimezone(timezone.utc)
    if time_bin == "H":
        return value.replace(minute=0, second=0, microsecond=0)
    if time_bin == "D":
        return value.replace(hour=0, minute=0, second=0, microsecond=0)
    if time_bin == "W":
        day = value.replace(hour=0, minute=0, second=0, microsecond=0)
        return day - timedelta(days=day.weekday())
    raise ValueError("time_bin must be one of H, D, or W")


def bin_events_by_time(
    events: Iterable[Event], feature_names: list[str], feature_fn: FeatureFn, time_bin: str = "D"
) -> tuple[list[datetime], np.ndarray]:
    bins: dict[datetime, list[dict[str, float | int | None]]] = defaultdict(list)
    for event in events:
        if event.time.start is not None:
            bins[_floor_time(event.time.start, time_bin)].append(feature_fn(event))
    times = sorted(bins)
    matrix = np.full((len(times), len(feature_names)), np.nan, dtype=float)
    for row, point in enumerate(times):
        for col, name in enumerate(feature_names):
            values = [float(item[name]) for item in bins[point] if item.get(name) is not None]
            if values:
                matrix[row, col] = float(np.mean(values))
    if matrix.size:
        medians = np.nanmedian(matrix, axis=0)
        medians = np.where(np.isnan(medians), 0.0, medians)
        matrix = np.where(np.isnan(matrix), medians, matrix)
    return times, matrix


def confidence_from_source_type(source_type: str) -> float:
    baselines = {
        "system_log": 0.95,
        "contemporaneous_record": 0.90,
        "photo_or_video": 0.85,
        "first_person_report": 0.70,
        "retrospective_account": 0.55,
        "derived_inference": 0.40,
    }
    return baselines.get(source_type, 0.50)


def serialize_model_outputs(outputs: Any) -> str:
    def default(value: Any):
        if isinstance(value, (datetime,)):
            return value.isoformat()
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, np.generic):
            return value.item()
        raise TypeError(f"cannot serialize {type(value).__name__}")

    return json.dumps(outputs, default=default, sort_keys=True, separators=(",", ":"))


def deserialize_model_outputs(blob: str) -> Any:
    return json.loads(blob)

