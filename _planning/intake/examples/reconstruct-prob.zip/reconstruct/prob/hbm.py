"""A compact hierarchical logistic trajectory model built with optional PyMC."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Callable

import numpy as np

from .data import Event


ObservationFn = Callable[[Event], tuple[float, dict[str, float]] | None]


class HierarchicalDeteriorationModel:
    def __init__(self, outcome_var: str, predictors: list[str]):
        self.outcome_var = outcome_var
        self.predictors = predictors
        self.model = None
        self.trace = None
        self.subject_index: dict[str, int] = {}

    def fit_population(
        self,
        all_events: Iterable[Event],
        observation_fn: ObservationFn,
        *,
        draws: int = 1000,
        tune: int = 1000,
        random_seed: int = 0,
    ) -> "HierarchicalDeteriorationModel":
        try:
            import pymc as pm
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Install reconstruct-prob[bayes]") from exc

        rows = [(event, observation_fn(event)) for event in all_events]
        rows = [(event, obs) for event, obs in rows if obs is not None]
        if not rows:
            raise ValueError("observation_fn produced no observations")
        subjects = sorted({event.subject_id for event, _ in rows})
        self.subject_index = {subject: index for index, subject in enumerate(subjects)}
        subject_idx = np.array([self.subject_index[event.subject_id] for event, _ in rows])
        y = np.array([obs[0] for _, obs in rows], dtype=int)
        x = np.array([[obs[1][name] for name in self.predictors] for _, obs in rows], dtype=float)

        with pm.Model(coords={"subject": subjects, "predictor": self.predictors}) as model:
            mu_intercept = pm.Normal("mu_intercept", 0, 1.5)
            sigma_intercept = pm.HalfNormal("sigma_intercept", 1)
            intercept = pm.Normal("intercept", mu_intercept, sigma_intercept, dims="subject")
            beta = pm.Normal("beta", 0, 1, dims="predictor")
            logit = intercept[subject_idx] + pm.math.dot(x, beta)
            pm.Bernoulli(self.outcome_var, logit_p=logit, observed=y)
            self.trace = pm.sample(draws=draws, tune=tune, random_seed=random_seed)
        self.model = model
        return self

    def get_subject_posterior(self, subject_id: str) -> dict[str, object]:
        if self.trace is None:
            raise RuntimeError("fit the population model first")
        if subject_id not in self.subject_index:
            raise KeyError(subject_id)
        try:
            import arviz as az
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Install reconstruct-prob[bayes]") from exc
        index = self.subject_index[subject_id]
        selected = self.trace.posterior.sel(subject=subject_id)
        summary = az.summary(selected, var_names=["intercept", "beta"], hdi_prob=0.94)
        return {"subject_id": subject_id, "subject_index": index, "summary": summary.to_dict()}
