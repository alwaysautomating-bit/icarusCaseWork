"""Prior construction, conjugate updates, and optional PyMC conversion."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable
from uuid import UUID, uuid4

from .data import Distribution, Prior


def create_beta_prior(
    name: str,
    domain: str,
    parameter: str,
    alpha: float,
    beta: float,
    source: str,
    *,
    owner_id: UUID | None = None,
    case_id: str | None = None,
    source_version: str | None = None,
    meta: dict[str, Any] | None = None,
) -> Prior:
    return Prior(
        owner_id=owner_id,
        case_id=case_id,
        name=name,
        domain=domain,
        parameter=parameter,
        distribution=Distribution.BETA,
        params={"alpha": alpha, "beta": beta},
        source=source,
        source_version=source_version,
        meta=meta or {},
    )


def get_priors(
    priors: Iterable[Prior], *, domain: str | None = None, parameter: str | None = None
) -> list[Prior]:
    return [
        prior
        for prior in priors
        if (domain is None or prior.domain == domain)
        and (parameter is None or prior.parameter == parameter)
    ]


def update_prior_with_counts(prior: Prior, successes: int, failures: int) -> Prior:
    if prior.distribution != Distribution.BETA:
        raise TypeError("conjugate count updates require a beta prior")
    if successes < 0 or failures < 0:
        raise ValueError("counts must be non-negative")
    return prior.model_copy(
        update={
            "id": uuid4(),
            "params": {
                "alpha": prior.params["alpha"] + successes,
                "beta": prior.params["beta"] + failures,
            },
            "parent_prior_id": prior.id,
            "created_at": datetime.now(timezone.utc),
        }
    )


def prior_to_pymc_distribution(prior: Prior, name: str | None = None):
    try:
        import pymc as pm
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise ImportError("Install reconstruct-prob[bayes]") from exc

    label = name or prior.parameter
    p = prior.params
    factories = {
        Distribution.BETA: lambda: pm.Beta(label, alpha=p["alpha"], beta=p["beta"]),
        Distribution.NORMAL: lambda: pm.Normal(label, mu=p["mu"], sigma=p["sigma"]),
        Distribution.GAMMA: lambda: pm.Gamma(label, alpha=p["alpha"], beta=p["beta"]),
        Distribution.LOGNORMAL: lambda: pm.LogNormal(label, mu=p["mu"], sigma=p["sigma"]),
        Distribution.HALF_NORMAL: lambda: pm.HalfNormal(label, sigma=p["sigma"]),
    }
    return factories[prior.distribution]()
