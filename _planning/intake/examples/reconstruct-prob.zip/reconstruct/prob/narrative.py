"""Competing-hypothesis scoring without converting likelihood into truth."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping

import numpy as np

from .data import Event


ScoreFn = Callable[[Iterable[Event], Mapping[str, object]], float]


class NarrativeModel:
    def __init__(self, narratives: dict[str, dict[str, object]], score_fn: ScoreFn):
        if not narratives:
            raise ValueError("at least one narrative is required")
        self.narratives = narratives
        self.score_fn = score_fn

    def score_narratives(self, events: Iterable[Event]) -> dict[str, dict[str, object]]:
        materialized = list(events)
        names = list(self.narratives)
        log_scores = []
        for name in names:
            spec = self.narratives[name]
            prior = float(spec.get("prior_probability", 1 / len(names)))
            if not 0 < prior <= 1:
                raise ValueError(f"invalid prior_probability for {name}")
            log_scores.append(self.score_fn(materialized, spec) + np.log(prior))
        shifted = np.asarray(log_scores) - np.max(log_scores)
        posterior = np.exp(shifted) / np.exp(shifted).sum()
        return {
            name: {
                "log_joint_score": float(log_scores[index]),
                "relative_posterior_weight": float(posterior[index]),
                "stressed_assumptions": self.narratives[name].get("stressed_assumptions", []),
            }
            for index, name in enumerate(names)
        }

