"""Validated, storage-friendly contracts shared by every model."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator


JsonObject = dict[str, Any]


class FrozenModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class TimePrecision(str, Enum):
    EXACT = "exact"
    MINUTE = "minute"
    HOUR = "hour"
    DAY = "day"
    RANGE = "range"
    UNKNOWN = "unknown"


class TimeWindow(FrozenModel):
    start: datetime | None = None
    end: datetime | None = None
    precision: TimePrecision = TimePrecision.UNKNOWN
    basis: str | None = None

    @model_validator(mode="after")
    def validate_window(self) -> "TimeWindow":
        if (self.start is None) != (self.end is None):
            raise ValueError("start and end must both be supplied or both omitted")
        if self.start and self.end and self.end < self.start:
            raise ValueError("end must be on or after start")
        if self.precision == TimePrecision.EXACT and self.start != self.end:
            raise ValueError("exact time requires start == end")
        return self


class Event(FrozenModel):
    id: UUID = Field(default_factory=uuid4)
    owner_id: UUID
    case_id: str = Field(min_length=1, max_length=200)
    subject_id: str = Field(min_length=1, max_length=200)
    event_type: str = Field(min_length=1, max_length=120)
    time: TimeWindow
    recorded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    payload: JsonObject = Field(default_factory=dict)
    tags: tuple[str, ...] = ()
    source_ids: tuple[str, ...] = ()
    confidence: float = Field(ge=0.0, le=1.0)
    supersedes_event_id: UUID | None = None
    meta: JsonObject = Field(default_factory=dict)


class ClaimStatus(str, Enum):
    ASSERTED = "asserted"
    SUPERSEDED = "superseded"
    RETRACTED = "retracted"


class Claim(FrozenModel):
    id: UUID = Field(default_factory=uuid4)
    owner_id: UUID
    case_id: str = Field(min_length=1, max_length=200)
    subject_id: str = Field(min_length=1, max_length=200)
    text: str = Field(min_length=1)
    time: TimeWindow | None = None
    confidence: float = Field(ge=0.0, le=1.0)
    status: ClaimStatus = ClaimStatus.ASSERTED
    uncertainty_notes: str | None = None
    supersedes_claim_id: UUID | None = None
    meta: JsonObject = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Distribution(str, Enum):
    BETA = "beta"
    NORMAL = "normal"
    GAMMA = "gamma"
    LOGNORMAL = "lognormal"
    HALF_NORMAL = "half_normal"


class Prior(FrozenModel):
    id: UUID = Field(default_factory=uuid4)
    owner_id: UUID | None = None
    case_id: str | None = None
    name: str = Field(min_length=1, max_length=200)
    domain: str = Field(min_length=1, max_length=120)
    parameter: str = Field(min_length=1, max_length=200)
    distribution: Distribution
    params: dict[str, float]
    source: str = Field(min_length=1)
    source_version: str | None = None
    parent_prior_id: UUID | None = None
    meta: JsonObject = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @model_validator(mode="after")
    def validate_params(self) -> "Prior":
        required = {
            Distribution.BETA: {"alpha", "beta"},
            Distribution.NORMAL: {"mu", "sigma"},
            Distribution.GAMMA: {"alpha", "beta"},
            Distribution.LOGNORMAL: {"mu", "sigma"},
            Distribution.HALF_NORMAL: {"sigma"},
        }[self.distribution]
        if not required.issubset(self.params):
            raise ValueError(f"{self.distribution.value} requires {sorted(required)}")
        if any(value <= 0 for key, value in self.params.items() if key in {"alpha", "beta", "sigma"}):
            raise ValueError("alpha, beta, and sigma parameters must be positive")
        return self


class ModelRunStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ModelRun(FrozenModel):
    id: UUID = Field(default_factory=uuid4)
    owner_id: UUID
    case_id: str = Field(min_length=1, max_length=200)
    subject_id: str = Field(min_length=1, max_length=200)
    model_type: str = Field(min_length=1, max_length=120)
    model_version: str = Field(min_length=1, max_length=80)
    status: ModelRunStatus = ModelRunStatus.QUEUED
    config: JsonObject = Field(default_factory=dict)
    outputs: JsonObject = Field(default_factory=dict)
    error: JsonObject | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    meta: JsonObject = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @model_validator(mode="after")
    def validate_lifecycle(self) -> "ModelRun":
        if self.status == ModelRunStatus.SUCCEEDED and self.completed_at is None:
            raise ValueError("succeeded runs require completed_at")
        if self.status == ModelRunStatus.FAILED and (self.completed_at is None or self.error is None):
            raise ValueError("failed runs require completed_at and error")
        return self

