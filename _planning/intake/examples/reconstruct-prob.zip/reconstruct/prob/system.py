"""Confidence-weighted beta-binomial model for system handoff fragmentation."""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np

from .data import Distribution, Event, Prior


class SystemFragmentationModel:
    def __init__(self, prior: Prior, high_threshold: float = 0.5, random_seed: int = 0):
        if prior.distribution != Distribution.BETA:
            raise TypeError("fragmentation requires a beta prior")
        if not 0 < high_threshold < 1:
            raise ValueError("high_threshold must be between zero and one")
        self.prior = prior
        self.high_threshold = high_threshold
        self.random_seed = random_seed

    def compute_fragmentation_score(
        self,
        events: Iterable[Event],
        handoff_event_types: tuple[str, ...] = ("referral", "follow_up_scheduled", "record_shared"),
        failure_types: tuple[str, ...] = (
            "missed_follow_up",
            "contradictory_instructions",
            "no_record_share",
        ),
    ) -> dict[str, float]:
        relevant = [event for event in events if event.event_type in {*handoff_event_types, *failure_types}]
        weighted_failures = sum(event.confidence for event in relevant if event.event_type in failure_types)
        weighted_successes = sum(event.confidence for event in relevant if event.event_type in handoff_event_types)
        alpha = self.prior.params["alpha"] + weighted_failures
        beta = self.prior.params["beta"] + weighted_successes
        mean = alpha / (alpha + beta)
        try:
            from scipy.stats import beta as beta_distribution

            p_high = float(1 - beta_distribution.cdf(self.high_threshold, alpha, beta))
            low, high = map(float, beta_distribution.ppf([0.03, 0.97], alpha, beta))
        except ImportError:  # deterministic approximation when scipy extra is absent
            draws = np.random.default_rng(self.random_seed).beta(alpha, beta, 50_000)
            p_high = float(np.mean(draws > self.high_threshold))
            low, high = map(float, np.quantile(draws, [0.03, 0.97]))
        opportunities = weighted_failures + weighted_successes
        return {
            "posterior_alpha": alpha,
            "posterior_beta": beta,
            "posterior_mean_fragmentation": mean,
            "p_high_fragmentation": p_high,
            "expected_missed_handoffs": opportunities * mean,
            "hdi_94_low": low,
            "hdi_94_high": high,
            "weighted_observations": opportunities,
        }

