"""Offline change-point detection with explicit resolution-based uncertainty."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from datetime import datetime

import numpy as np

from .data import Event


SeriesFn = Callable[[Iterable[Event]], tuple[list[datetime], list[float]]]


class ChangePointDetector:
    def __init__(self, series_fn: SeriesFn, method: str = "pelt", model: str = "rbf"):
        if method not in {"pelt", "binseg", "window"}:
            raise ValueError("method must be pelt, binseg, or window")
        self.series_fn = series_fn
        self.method = method
        self.model = model

    def detect(
        self, events: Iterable[Event], *, penalty: float = 3.0, n_change_points: int | None = None
    ) -> list[dict[str, object]]:
        try:
            import ruptures as rpt
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Install reconstruct-prob[changepoint]") from exc
        times, raw = self.series_fn(events)
        values = np.asarray(raw, dtype=float).reshape(-1, 1)
        if len(values) < 4:
            return []
        if self.method == "pelt":
            indexes = rpt.Pelt(model=self.model).fit(values).predict(pen=penalty)
        elif self.method == "binseg":
            indexes = rpt.Binseg(model=self.model).fit(values).predict(n_bkps=n_change_points or 1)
        else:
            indexes = rpt.Window(width=max(2, min(10, len(values) // 3)), model=self.model).fit(values).predict(
                n_bkps=n_change_points or 1
            )
        output = []
        for index in indexes:
            if index >= len(times):  # ruptures includes the terminal boundary
                continue
            output.append(
                {
                    "time": times[index],
                    "index": index,
                    "resolution_interval": [times[index - 1], times[index]],
                    "method": self.method,
                    "uncertainty_kind": "sampling_resolution_not_credible_interval",
                }
            )
        return output

