"""Optional Gaussian HMM adapter for latent, time-indexed states."""

from __future__ import annotations

from typing import Callable, Iterable

import numpy as np

from .data import Event
from .utils import FeatureFn, bin_events_by_time


class LatentStateHMM:
    def __init__(
        self,
        n_states: int,
        observation_features: list[str],
        prior_transition: np.ndarray | None = None,
        prior_start: np.ndarray | None = None,
        *,
        random_state: int = 0,
        n_iter: int = 200,
    ):
        if n_states < 2:
            raise ValueError("n_states must be at least 2")
        self.n_states = n_states
        self.observation_features = observation_features
        self.prior_transition = prior_transition
        self.prior_start = prior_start
        self.random_state = random_state
        self.n_iter = n_iter
        self.model = None

    def _matrix(self, events: Iterable[Event], time_bin: str, feature_fn: FeatureFn):
        times, matrix = bin_events_by_time(events, self.observation_features, feature_fn, time_bin)
        if len(times) < self.n_states:
            raise ValueError("need at least n_states non-empty time bins")
        return times, matrix

    def fit(
        self, events: Iterable[Event], time_bin: str = "D", feature_fn: FeatureFn | None = None
    ) -> "LatentStateHMM":
        if feature_fn is None:
            raise ValueError("feature_fn is required; domain features must be explicit")
        try:
            from hmmlearn.hmm import GaussianHMM
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Install reconstruct-prob[hmm]") from exc
        _, matrix = self._matrix(events, time_bin, feature_fn)
        init_params = "mc"
        model = GaussianHMM(
            n_components=self.n_states,
            covariance_type="diag",
            n_iter=self.n_iter,
            random_state=self.random_state,
            init_params=init_params,
            params="stmc",
        )
        if self.prior_transition is not None:
            transition = np.asarray(self.prior_transition, dtype=float)
            if transition.shape != (self.n_states, self.n_states):
                raise ValueError("prior_transition has the wrong shape")
            model.transmat_ = transition / transition.sum(axis=1, keepdims=True)
        if self.prior_start is not None:
            start = np.asarray(self.prior_start, dtype=float)
            if start.shape != (self.n_states,):
                raise ValueError("prior_start has the wrong shape")
            model.startprob_ = start / start.sum()
        model.fit(matrix)
        self.model = model
        return self

    def infer_state_probabilities(
        self, events: Iterable[Event], time_bin: str = "D", feature_fn: FeatureFn | None = None
    ) -> list[dict[int, float]]:
        if self.model is None:
            raise RuntimeError("fit the model first")
        if feature_fn is None:
            raise ValueError("feature_fn is required")
        _, matrix = self._matrix(events, time_bin, feature_fn)
        return [dict(enumerate(map(float, row))) for row in self.model.predict_proba(matrix)]

    def most_likely_state_sequence(
        self, events: Iterable[Event], time_bin: str = "D", feature_fn: FeatureFn | None = None
    ) -> list[int]:
        if self.model is None:
            raise RuntimeError("fit the model first")
        if feature_fn is None:
            raise ValueError("feature_fn is required")
        _, matrix = self._matrix(events, time_bin, feature_fn)
        return [int(value) for value in self.model.predict(matrix)]

    def log_likelihood(
        self, events: Iterable[Event], *, time_bin: str = "D", feature_fn: FeatureFn
    ) -> float:
        if self.model is None:
            raise RuntimeError("fit the model first")
        _, matrix = self._matrix(events, time_bin, feature_fn)
        return float(self.model.score(matrix))

