"""Optional lifelines adapter for Cox and Weibull time-to-event models."""

from __future__ import annotations

from typing import Any


class TimeToEventModel:
    def __init__(self, event_type: str, covariates: list[str], model_type: str = "cox"):
        if model_type not in {"cox", "weibull"}:
            raise ValueError("model_type must be cox or weibull")
        self.event_type = event_type
        self.covariates = covariates
        self.model_type = model_type
        self.model = None

    def fit_dataframe(
        self, frame: Any, *, duration_col: str = "duration", observed_col: str = "observed"
    ) -> "TimeToEventModel":
        try:
            from lifelines import CoxPHFitter, WeibullAFTFitter
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Install reconstruct-prob[survival]") from exc
        columns = [duration_col, observed_col, *self.covariates]
        data = frame.loc[:, columns].copy()
        model = CoxPHFitter() if self.model_type == "cox" else WeibullAFTFitter()
        model.fit(data, duration_col=duration_col, event_col=observed_col)
        self.model = model
        return self

    def predict(self, covariate_frame: Any, times: list[float]) -> dict[str, list[float]]:
        if self.model is None:
            raise RuntimeError("fit the model first")
        survival = self.model.predict_survival_function(covariate_frame, times=times)
        result = {"times": [float(value) for value in survival.index]}
        for column in survival.columns:
            result[f"survival_{column}"] = [float(value) for value in survival[column]]
        return result

