from datetime import datetime, timezone
from uuid import uuid4

import pytest

from reconstruct.prob.data import Event, TimePrecision, TimeWindow
from reconstruct.prob.priors import create_beta_prior, update_prior_with_counts
from reconstruct.prob.system import SystemFragmentationModel
from reconstruct.prob.utils import bin_events_by_time, deserialize_model_outputs, serialize_model_outputs


NOW = datetime(2026, 1, 1, 12, tzinfo=timezone.utc)


def event(event_type: str, confidence: float = 1.0) -> Event:
    return Event(
        owner_id=uuid4(),
        case_id="case-1",
        subject_id="subject-1",
        event_type=event_type,
        time=TimeWindow(start=NOW, end=NOW, precision=TimePrecision.EXACT),
        confidence=confidence,
        payload={"value": 2},
    )


def test_time_window_rejects_reversed_range():
    with pytest.raises(ValueError):
        TimeWindow(start=NOW, end=NOW.replace(hour=11), precision=TimePrecision.RANGE)


def test_beta_update_is_versioned_and_conjugate():
    prior = create_beta_prior("handoffs", "generic", "p_failure", 1, 1, "test")
    posterior = update_prior_with_counts(prior, successes=2, failures=3)
    assert posterior.params == {"alpha": 3, "beta": 4}
    assert posterior.parent_prior_id == prior.id
    assert posterior.id != prior.id


def test_fragmentation_is_confidence_weighted():
    prior = create_beta_prior("handoffs", "generic", "p_failure", 1, 1, "test")
    score = SystemFragmentationModel(prior).compute_fragmentation_score(
        [event("missed_follow_up", 0.5), event("record_shared", 1.0)]
    )
    assert score["posterior_alpha"] == 1.5
    assert score["posterior_beta"] == 2.0


def test_time_binning_and_serialization():
    item = event("measurement")
    times, matrix = bin_events_by_time([item], ["value"], lambda e: e.payload, "D")
    restored = deserialize_model_outputs(serialize_model_outputs({"times": times, "matrix": matrix}))
    assert restored["matrix"] == [[2.0]]

