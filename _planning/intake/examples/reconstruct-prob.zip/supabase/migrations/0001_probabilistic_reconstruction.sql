-- Probabilistic reconstruction storage.
-- Core records are tenant-scoped by owner_id + case_id. Shared priors have owner_id NULL.

create table if not exists public.reconstruction_events (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  case_id text not null check (length(case_id) between 1 and 200),
  subject_id text not null check (length(subject_id) between 1 and 200),
  event_type text not null check (length(event_type) between 1 and 120),
  occurred_start timestamptz,
  occurred_end timestamptz,
  time_precision text not null default 'unknown'
    check (time_precision in ('exact', 'minute', 'hour', 'day', 'range', 'unknown')),
  time_basis text,
  recorded_at timestamptz not null default now(),
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object'),
  tags text[] not null default '{}',
  source_ids text[] not null default '{}',
  confidence double precision not null check (confidence between 0 and 1),
  supersedes_event_id uuid references public.reconstruction_events(id),
  meta jsonb not null default '{}'::jsonb check (jsonb_typeof(meta) = 'object'),
  created_at timestamptz not null default now(),
  constraint event_time_pair check ((occurred_start is null) = (occurred_end is null)),
  constraint event_time_order check (occurred_end is null or occurred_end >= occurred_start),
  constraint exact_event_time check (
    time_precision <> 'exact' or (occurred_start is not null and occurred_start = occurred_end)
  ),
  unique (id, owner_id, case_id)
);

create table if not exists public.reconstruction_priors (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  case_id text check (case_id is null or length(case_id) between 1 and 200),
  name text not null check (length(name) between 1 and 200),
  domain text not null check (length(domain) between 1 and 120),
  parameter text not null check (length(parameter) between 1 and 200),
  distribution text not null
    check (distribution in ('beta', 'normal', 'gamma', 'lognormal', 'half_normal')),
  params jsonb not null check (jsonb_typeof(params) = 'object'),
  source text not null check (length(source) > 0),
  source_version text,
  parent_prior_id uuid references public.reconstruction_priors(id),
  meta jsonb not null default '{}'::jsonb check (jsonb_typeof(meta) = 'object'),
  created_at timestamptz not null default now(),
  constraint shared_prior_has_no_case check (owner_id is not null or case_id is null),
  constraint beta_prior_shape check (
    distribution <> 'beta' or (
      jsonb_typeof(params -> 'alpha') = 'number'
      and jsonb_typeof(params -> 'beta') = 'number'
      and (params ->> 'alpha')::double precision > 0
      and (params ->> 'beta')::double precision > 0
    )
  )
);

create table if not exists public.reconstruction_model_runs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  case_id text not null check (length(case_id) between 1 and 200),
  subject_id text not null check (length(subject_id) between 1 and 200),
  model_type text not null check (length(model_type) between 1 and 120),
  model_version text not null check (length(model_version) between 1 and 80),
  status text not null default 'queued'
    check (status in ('queued', 'running', 'succeeded', 'failed', 'cancelled')),
  config jsonb not null default '{}'::jsonb check (jsonb_typeof(config) = 'object'),
  outputs jsonb not null default '{}'::jsonb check (jsonb_typeof(outputs) = 'object'),
  error jsonb check (error is null or jsonb_typeof(error) = 'object'),
  started_at timestamptz,
  completed_at timestamptz,
  meta jsonb not null default '{}'::jsonb check (jsonb_typeof(meta) = 'object'),
  created_at timestamptz not null default now(),
  constraint completed_run_shape check (
    (status = 'succeeded' and completed_at is not null)
    or (status = 'failed' and completed_at is not null and error is not null)
    or status in ('queued', 'running', 'cancelled')
  ),
  unique (id, owner_id, case_id)
);

create table if not exists public.reconstruction_claims (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  case_id text not null check (length(case_id) between 1 and 200),
  subject_id text not null check (length(subject_id) between 1 and 200),
  claim_text text not null check (length(claim_text) > 0),
  occurred_start timestamptz,
  occurred_end timestamptz,
  time_precision text
    check (time_precision is null or time_precision in ('exact', 'minute', 'hour', 'day', 'range', 'unknown')),
  time_basis text,
  confidence double precision not null check (confidence between 0 and 1),
  status text not null default 'asserted'
    check (status in ('asserted', 'superseded', 'retracted')),
  uncertainty_notes text,
  supersedes_claim_id uuid references public.reconstruction_claims(id),
  meta jsonb not null default '{}'::jsonb check (jsonb_typeof(meta) = 'object'),
  created_at timestamptz not null default now(),
  constraint claim_time_pair check ((occurred_start is null) = (occurred_end is null)),
  constraint claim_time_order check (occurred_end is null or occurred_end >= occurred_start),
  unique (id, owner_id, case_id)
);

-- Junction tables preserve referential integrity; UUID arrays cannot enforce it.
create table if not exists public.reconstruction_claim_events (
  claim_id uuid not null,
  event_id uuid not null,
  owner_id uuid not null,
  case_id text not null,
  support_role text not null default 'supports'
    check (support_role in ('supports', 'contradicts', 'contextualizes')),
  created_at timestamptz not null default now(),
  primary key (claim_id, event_id, support_role),
  foreign key (claim_id, owner_id, case_id)
    references public.reconstruction_claims(id, owner_id, case_id) on delete cascade,
  foreign key (event_id, owner_id, case_id)
    references public.reconstruction_events(id, owner_id, case_id) on delete cascade
);

create table if not exists public.reconstruction_model_run_events (
  model_run_id uuid not null,
  event_id uuid not null,
  owner_id uuid not null,
  case_id text not null,
  created_at timestamptz not null default now(),
  primary key (model_run_id, event_id),
  foreign key (model_run_id, owner_id, case_id)
    references public.reconstruction_model_runs(id, owner_id, case_id) on delete cascade,
  foreign key (event_id, owner_id, case_id)
    references public.reconstruction_events(id, owner_id, case_id) on delete restrict
);

create table if not exists public.reconstruction_model_run_priors (
  model_run_id uuid not null,
  prior_id uuid not null references public.reconstruction_priors(id) on delete restrict,
  owner_id uuid not null,
  case_id text not null,
  created_at timestamptz not null default now(),
  primary key (model_run_id, prior_id),
  foreign key (model_run_id, owner_id, case_id)
    references public.reconstruction_model_runs(id, owner_id, case_id) on delete cascade
);

create index if not exists reconstruction_events_timeline_idx
  on public.reconstruction_events (owner_id, case_id, subject_id, occurred_start);
create index if not exists reconstruction_events_type_idx
  on public.reconstruction_events (owner_id, case_id, event_type);
create index if not exists reconstruction_events_tags_gin
  on public.reconstruction_events using gin (tags);
create index if not exists reconstruction_priors_lookup_idx
  on public.reconstruction_priors (domain, parameter, created_at desc);
create index if not exists reconstruction_model_runs_subject_idx
  on public.reconstruction_model_runs (owner_id, case_id, subject_id, created_at desc);
create index if not exists reconstruction_claims_subject_idx
  on public.reconstruction_claims (owner_id, case_id, subject_id, created_at desc);

alter table public.reconstruction_events enable row level security;
alter table public.reconstruction_priors enable row level security;
alter table public.reconstruction_model_runs enable row level security;
alter table public.reconstruction_claims enable row level security;
alter table public.reconstruction_claim_events enable row level security;
alter table public.reconstruction_model_run_events enable row level security;
alter table public.reconstruction_model_run_priors enable row level security;

grant select, insert, update, delete on public.reconstruction_events to authenticated;
grant select, insert, update, delete on public.reconstruction_priors to authenticated;
grant select, insert, update, delete on public.reconstruction_model_runs to authenticated;
grant select, insert, update, delete on public.reconstruction_claims to authenticated;
grant select, insert, update, delete on public.reconstruction_claim_events to authenticated;
grant select, insert, update, delete on public.reconstruction_model_run_events to authenticated;
grant select, insert, update, delete on public.reconstruction_model_run_priors to authenticated;

create policy events_owner_all on public.reconstruction_events
  for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);

create policy priors_owner_read on public.reconstruction_priors
  for select to authenticated
  using (owner_id is null or (select auth.uid()) = owner_id);
create policy priors_owner_insert on public.reconstruction_priors
  for insert to authenticated
  with check ((select auth.uid()) = owner_id);
create policy priors_owner_update on public.reconstruction_priors
  for update to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);
create policy priors_owner_delete on public.reconstruction_priors
  for delete to authenticated
  using ((select auth.uid()) = owner_id);

create policy model_runs_owner_all on public.reconstruction_model_runs
  for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);
create policy claims_owner_all on public.reconstruction_claims
  for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);
create policy claim_events_owner_all on public.reconstruction_claim_events
  for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);
create policy model_run_events_owner_all on public.reconstruction_model_run_events
  for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);
create policy model_run_priors_owner_all on public.reconstruction_model_run_priors
  for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check (
    (select auth.uid()) = owner_id
    and exists (
      select 1 from public.reconstruction_priors p
      where p.id = prior_id and (p.owner_id is null or p.owner_id = (select auth.uid()))
    )
  );
