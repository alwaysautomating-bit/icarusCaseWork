# Sources and implementation references

These are implementation references, not domain priors. A domain prior should cite the population, outcome definition, study design, version, and extraction method used to create its parameters.

## Algorithms and libraries

- PyMC Beta distribution: <https://www.pymc.io/projects/docs/en/stable/api/distributions/generated/pymc.Beta.html>
- hmmlearn HMM tutorial: <https://hmmlearn.readthedocs.io/en/stable/tutorial.html>
- lifelines Cox proportional-hazards fitter: <https://lifelines.readthedocs.io/en/latest/fitters/regression/CoxPHFitter.html>
- lifelines proportional-hazards assumption checks: <https://lifelines.readthedocs.io/en/latest/jupyter_notebooks/Proportional%20hazard%20assumption.html>
- ruptures change-point documentation: <https://centre-borelli.github.io/ruptures-docs/>
- PELT reference: Killick, Fearnhead, and Eckley (2012), linked from <https://centre-borelli.github.io/ruptures-docs/user-guide/detection/pelt/>
- Splink probabilistic record linkage: <https://moj-analytical-services.github.io/splink/index.html>
- Splink Fellegi-Sunter model: <https://moj-analytical-services.github.io/splink/topic_guides/theory/fellegi_sunter.html>

## Supabase and Postgres

- Supabase Row Level Security: <https://supabase.com/docs/guides/database/postgres/row-level-security>
- Supabase JSON and JSONB: <https://supabase.com/docs/guides/database/json>
- PostgreSQL row security policies: <https://www.postgresql.org/docs/current/ddl-rowsecurity.html>
- PostgreSQL JSON types: <https://www.postgresql.org/docs/current/datatype-json.html>
- PostgreSQL range types: <https://www.postgresql.org/docs/current/rangetypes.html>

## Provenance requirement for domain priors

For every production prior, preserve at least:

- exact source and source version;
- population and inclusion/exclusion criteria;
- numerator, denominator, and outcome definition;
- time window and censoring rule;
- transformations used to derive distribution parameters;
- known applicability limits and bias risks;
- reviewer and approval date.

